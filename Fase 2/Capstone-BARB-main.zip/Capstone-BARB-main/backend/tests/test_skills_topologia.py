"""Las 3 Skills de topología (HU-26): listar, actualizar parámetros y crear planta.

Lo que se prueba acá es lo que podría salir caro: que ninguna tool exponga identificadores
al modelo (§2 de la spec), que otra empresa no vea ni modifique nada, que la escritura
requiera el permiso del mantenedor (admin) y que sin confirmación del usuario no
se escriba nada (el candado de planta, mismo patrón que el de OTs en test_candado_ot.py).

Los tests de integración contra la base son explícitos: lo que se crea se limpia (planta
→ máquinas → sesiones, porque `fk_maquina_planta` no tiene CASCADE).
"""

from __future__ import annotations

import uuid

import pytest
import pytest_asyncio
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage

from barb.core.db import execute, fetch_one
from barb.services import chat_graph
from barb.services.ai_tools import (
    _PREFIJO_PROPUESTA_PARAMETROS,
    _PREFIJO_PROPUESTA_PLANTA,
    PERMISO_DENEGADO,
    _parsear_propuesta_parametros,
    _parsear_propuesta_planta,
    _texto_propuesta_parametros,
    _texto_propuesta_planta,
    actualizar_parametros_aprobada,
    crear_planta_aprobada,
    crear_tools,
)
from barb.services.chat_graph import crear_grafo

ADMIN_ID = 1  # admin de la empresa 1 (el mantenedor de plantas es solo del admin)
OTRA_EMPRESA_ID = 16  # admin de la empresa 2 (tiene permiso sobre `plantas`)

# Nada de estos identificadores puede aparecer en el schema que ve el modelo (spec §2).
SENSIBLES = {"empresa_id", "usuario_id", "rol", "maquina_id", "planta_id"}

HERRAMIENTAS = {t.name: t for t in crear_tools(empresa_id=1, usuario_id=ADMIN_ID, rol="admin")}


@pytest_asyncio.fixture
async def ctx(db_pool):
    """Tokens de sesión (admin local + admin ajeno) y limpieza por marca."""
    marca = uuid.uuid4().hex[:8]
    tokens: dict[str, dict[str, str]] = {}
    for nombre, uid in (("admin", ADMIN_ID), ("ajeno", OTRA_EMPRESA_ID)):
        token = f"test-skill-{nombre}-{marca}"
        await execute(
            "INSERT INTO sesion (token, usuario_id, expira_en) VALUES (%(t)s, %(u)s, NOW() + INTERVAL '10 minutes')",
            {"t": token, "u": uid},
        )
        tokens[nombre] = {"Authorization": f"Bearer {token}"}

    yield {"tokens": tokens, "marca": marca}

    await execute(
        "DELETE FROM maquina WHERE planta_id IN (SELECT planta_id FROM planta WHERE nombre LIKE %(p)s)",
        {"p": f"%{marca}%"},
    )
    await execute("DELETE FROM planta WHERE nombre LIKE %(p)s", {"p": f"%{marca}%"})
    await execute("DELETE FROM sesion WHERE token LIKE %(p)s", {"p": f"test-skill-%-{marca}"})


async def _planta_con_dos_maquinas(client, ctx) -> int:
    """Una planta con 2 máquinas: la primera con SLA y costo, la segunda sin (NULL)."""
    r = await client.post(
        "/api/plantas/completa",
        headers=ctx["tokens"]["admin"],
        json={
            "nombre": f"Planta Skill {ctx['marca']}",
            "maquinas": [
                {
                    "nombre": f"Compresor {ctx['marca']}",
                    "codigo": "COMP",
                    "disciplina": "Mecánica",
                    "sla_horas": 6,
                    "costo_inactividad_minuto": 50,
                },
                {"nombre": "Prensa", "codigo": "PRE", "disciplina": "Eléctrica"},
            ],
        },
    )
    assert r.status_code == 201, r.text
    cuerpo = r.json()
    return cuerpo["planta_id"], cuerpo["maquinas"][0]["maquina_id"]


# =============================================================================
# Seguridad: el modelo nunca ve identificadores
# =============================================================================


@pytest.mark.parametrize(
    "nombre_tool",
    ["listar_maquinas_planta", "actualizar_parametros_maquina", "proponer_planta_completa", "proponer_aviso_falla"],
)
def test_las_tools_no_exponen_identificadores(nombre_tool):
    """El modelo no debe poder escribir ni la empresa ni el usuario ni un id suelto."""
    esquema = HERRAMIENTAS[nombre_tool].args_schema.model_json_schema()
    expuestos = set(esquema.get("properties", {})) & SENSIBLES
    assert not expuestos, f"{nombre_tool} expone {expuestos} al modelo"


# =============================================================================
# Skill 1: listar_maquinas_planta
# =============================================================================


@pytest.mark.asyncio
async def test_listar_maquinas_planta_no_cruza_empresas(client, ctx):
    """Con empresa 2, pedir la planta de la empresa 1 devuelve «no encontré» y no lista
    sus máquinas: el filtro de empresa va en el WHERE."""
    await _planta_con_dos_maquinas(client, ctx)

    ajenas = {t.name: t for t in crear_tools(empresa_id=2, usuario_id=OTRA_EMPRESA_ID, rol="admin")}
    salida = await ajenas["listar_maquinas_planta"].ainvoke({"planta": f"Planta Skill {ctx['marca']}"})

    assert "No encontré" in salida
    assert "Compressor" not in salida


@pytest.mark.asyncio
async def test_listar_maquinas_planta_muestra_sla_y_costo(client, ctx):
    """La lectura muestra SLA y costo; con NULL dice «el general» (no inventa valores)."""
    await _planta_con_dos_maquinas(client, ctx)

    salida = await HERRAMIENTAS["listar_maquinas_planta"].ainvoke({"planta": f"Planta Skill {ctx['marca']}"})

    assert f"Compresor {ctx['marca']}" in salida and "PRE" in salida
    assert "6 h" in salida and "| 50 |" in salida, "los valores cargados se muestran (tabla)"
    assert "| Máquina |" in salida, "el listado viene en tabla"
    assert salida.count("el general") == 2, "SLA y costo de la máquina sin valores: dos «el general»"


# =============================================================================
# Skill 2: actualizar_parametros_maquina
# =============================================================================


@pytest.mark.asyncio
async def test_actualizar_parametros_maquina_respeta_empresa(client, ctx):
    """Un admin de la empresa 2 no puede editar la máquina de la empresa 1 — y el valor
    en la base no cambia."""
    _, maquina_id = await _planta_con_dos_maquinas(client, ctx)
    ajenas = {t.name: t for t in crear_tools(empresa_id=2, usuario_id=OTRA_EMPRESA_ID, rol="admin")}

    salida = await ajenas["actualizar_parametros_maquina"].ainvoke(
        {"nombre_maquina": f"Compresor {ctx['marca']}", "sla_horas": 1}
    )

    assert "No encontré" in salida
    fila = await fetch_one("SELECT sla_horas FROM maquina WHERE maquina_id = %(m)s", {"m": maquina_id})
    assert float(fila["sla_horas"]) == 6, "el SLA de la empresa 1 quedó intacto"


@pytest.mark.asyncio
async def test_actualizar_parametros_maquina_requiere_permiso(client, ctx):
    """Un técnico no gestiona el mantenedor (misma matriz que el endpoint): la tool lo
    rechaza sin tocar la base."""
    _, maquina_id = await _planta_con_dos_maquinas(client, ctx)
    tecnicas = {t.name: t for t in crear_tools(empresa_id=1, usuario_id=4, rol="tecnico")}

    salida = await tecnicas["actualizar_parametros_maquina"].ainvoke(
        {"nombre_maquina": f"Compresor {ctx['marca']}", "sla_horas": 9}
    )

    assert salida == PERMISO_DENEGADO
    fila = await fetch_one("SELECT sla_horas FROM maquina WHERE maquina_id = %(m)s", {"m": maquina_id})
    assert float(fila["sla_horas"]) == 6


@pytest.mark.asyncio
async def test_actualizar_parametros_maquina_cambia_sla_y_costo(client, ctx):
    """El caso feliz PERO ahora con candado: la tool solo PROPONE (sin escribir); el
    write real lo hace `actualizar_parametros_aprobada` tras el «sí» del gate."""
    _, maquina_id = await _planta_con_dos_maquinas(client, ctx)

    propuesta = await HERRAMIENTAS["actualizar_parametros_maquina"].ainvoke(
        {"nombre_maquina": f"Compresor {ctx['marca']}", "sla_horas": 8, "costo_inactividad_minuto": 120}
    )

    # 1) La tool solo redacta: propuesta parseable y la base SIN cambios.
    assert propuesta.startswith(_PREFIJO_PROPUESTA_PARAMETROS)
    assert "¿Confirmas el cambio?" in propuesta
    borrador = _parsear_propuesta_parametros(propuesta)
    assert borrador and borrador["tipo"] == "parametros"
    assert borrador["sla_horas"] == 8 and borrador["costo_inactividad_minuto"] == 120
    fila = await fetch_one(
        "SELECT sla_horas, costo_inactividad_minuto FROM maquina WHERE maquina_id = %(m)s",
        {"m": maquina_id},
    )
    assert float(fila["sla_horas"]) == 6 and float(fila["costo_inactividad_minuto"]) == 50, "sin confirmación no escribe"

    # 2) Con el «sí», el write por el gate: misma máquina, valores nuevos.
    salida = await actualizar_parametros_aprobada(
        borrador["codigo"],
        borrador["sla_horas"],
        borrador["costo_inactividad_minuto"],
        empresa_id=1,
        usuario_id=ADMIN_ID,
        rol="admin",
    )

    assert f"Actualicé «Compresor {ctx['marca']}»" in salida
    assert "6 h → 8 h" in salida, "antes → después del SLA"
    assert "50 /min → 120 /min" in salida, "antes → después del costo"
    fila = await fetch_one(
        "SELECT sla_horas, costo_inactividad_minuto FROM maquina WHERE maquina_id = %(m)s",
        {"m": maquina_id},
    )
    assert float(fila["sla_horas"]) == 8 and float(fila["costo_inactividad_minuto"]) == 120


@pytest.mark.asyncio
async def test_actualizar_parametros_maquina_rechaza_valores_invalidos(db_pool):
    """Rangos fuera de lugar o llamada sin campos: mensaje claro, base sin tocar."""
    for args, esperado in (
        ({"nombre_maquina": "Compressor", "sla_horas": -1}, "entre 0 y 8760"),
        ({"nombre_maquina": "Compressor", "sla_horas": 9000}, "entre 0 y 8760"),
        ({"nombre_maquina": "Compressor"}, "Di qué cambias"),
    ):
        salida = await HERRAMIENTAS["actualizar_parametros_maquina"].ainvoke(args)
        assert esperado in salida, f"{args}: {salida}"


async def test_actualizar_parametros_aprobada_revalida_y_no_adivina(db_pool):
    """El write del gate revalida TODO: propuesta sin valores nuevos se descarta; la
    máquina se re-resuelve por CÓDIGO exacto y el permiso se vuelve a chequear."""
    # Sin valores: no hay nada que escribir.
    salida = await actualizar_parametros_aprobada("BOM-001", None, None, empresa_id=1, usuario_id=ADMIN_ID, rol="admin")
    assert "no indicaba ningún valor" in salida

    # Fuera de rango: no escribe aunque llegue con «sí».
    salida = await actualizar_parametros_aprobada("BOM-001", 99999.0, None, empresa_id=1, usuario_id=ADMIN_ID, rol="admin")
    assert "fuera de rango" in salida

    # Código que NO existe: no adivina, no escribe.
    salida = await actualizar_parametros_aprobada("XYZ-NADIE", 8.0, None, empresa_id=1, usuario_id=ADMIN_ID, rol="admin")
    assert "No encontré la máquina" in salida

    # Sin permiso: el gate vuelve a chequear el rol, no confía en el turno anterior.
    salida = await actualizar_parametros_aprobada("BOM-001", 8.0, None, empresa_id=1, usuario_id=4, rol="tecnico")
    assert salida == PERMISO_DENEGADO
    fila_antes = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = %(c)s", {"c": "BOM-001"})
    fila = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = %(c)s", {"c": "BOM-001"})
    assert float(fila["sla_horas"] or -1) == float(fila_antes["sla_horas"] or -1), "sin permiso ni con «sí» no cambia nada"


def test_la_propuesta_de_parametros_parsea_redonda():
    """Round-trip del texto: lo que redacta la tool es EXACTO lo que parsea el gate
    (con el SLA intacto y el campo no tocado vacío)."""
    texto = _texto_propuesta_parametros(
        {"nombre": "Pump E4", "codigo": "PUMP-E4", "planta": "Planta Central San Bernardo"},
        {"sla_horas": 6, "costo_inactividad_minuto": None},
        {"sla_horas": 8.0},
    )

    assert texto.startswith(_PREFIJO_PROPUESTA_PARAMETROS)
    datos = _parsear_propuesta_parametros(texto)
    assert datos["tipo"] == "parametros"
    assert datos["codigo"] == "PUMP-E4" and datos["nombre"] == "Pump E4"
    assert datos["sla_horas"] == 8.0
    assert datos["costo_inactividad_minuto"] is None, "costo no tocado = sin cambio"

    # Formato roto (parseo que no cierra) se descarta: nunca se interpreta el
    # basura como aprobación.
    corrompido = texto.replace("| **sla:** 8", "| **sla:** carne")
    assert _parsear_propuesta_parametros(corrompido) is None

    # Y una propuesta sin la línea de la máquina (incompleta): no es interpretable.
    assert _parsear_propuesta_parametros(f"{_PREFIJO_PROPUESTA_PARAMETROS}\n\n¿Confirmas?") is None


# =============================================================================
# Skill 3: proponer_planta_completa + crear_planta_aprobada (el candado)
# =============================================================================


@pytest.mark.asyncio
async def test_proponer_planta_completa_no_escribe_nada(db_pool):
    """La tool de propuesta valida y redacta, pero NO inserta nada: ni planta ni máquinas."""
    antes = await fetch_one("SELECT COUNT(*) AS n FROM planta")

    # «Quilicura» está tomada por la planta del seed (la regla anti-duplicado la
    # detecta); ubicación inocente para proponer en los tests:
    salida = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {
            "nombre": "Planta Propuesta",
            "ubicacion": "Ventarrón 889",
            "maquinas": [
                {"nombre": "Turbina 1", "codigo": "TUR-1", "disciplina": "Mecánica"},
                {"nombre": "Turbina 2", "codigo": "TUR-2", "disciplina": "Mecánica"},
            ],
        }
    )

    despues = await fetch_one("SELECT COUNT(*) AS n FROM planta")
    assert antes["n"] == despues["n"], "la propuesta no debe crear filas"
    assert salida.startswith(_PREFIJO_PROPUESTA_PLANTA)


async def test_la_propuesta_parsea_con_la_ubicacion_completa(db_pool):
    """Round-trip de la propuesta: lo que muestra la tool es EXACTO lo que parsea el gate.

    Regresión del E2E: el `[^»]+?` perezoso con un grupo opcional a la derecha capturaba
    la primera letra de la ubicación («Q») y la planta se creaba con 1 caracter.
    """
    texto = _texto_propuesta_planta(
        "Planta Round Trip",
        "Quilicura",
        [{"nombre": "Turbina 1", "codigo": "TRT-1", "disciplina": "Mecánica"}],
    )
    datos = _parsear_propuesta_planta(texto)

    assert datos["ubicacion"] == "Quilicura"

    # Y sin ubicación explícita: None, no basura.
    sin_ubicacion = _texto_propuesta_planta(
        "Planta Sin Lugar",
        None,
        [{"nombre": "Turbina 2", "codigo": "TRT-2"}],
    )
    assert _parsear_propuesta_planta(sin_ubicacion)["ubicacion"] is None


@pytest.mark.asyncio
async def test_crear_planta_aprobada_crea_planta_y_maquinas(db_pool):
    """El INSERT aprobado crea la planta con sus máquinas y los valores pedidos."""
    marca = uuid.uuid4().hex[:8]
    try:
        salida = await crear_planta_aprobada(
            f"Planta Aprobada {marca}",
            [
                {
                    "nombre": "Turbina 1",
                    "codigo": "TUR-1",
                    "disciplina": "Mecánica",
                    "sla_horas": 4,
                    "costo_inactividad_minuto": 30,
                },
                {"nombre": "Turbina 2", "codigo": "TUR-2", "disciplina": "Mecánica"},
            ],
            empresa_id=1,
            usuario_id=ADMIN_ID,
            rol="admin",
        )

        assert "creada con 2 máquina(s)" in salida
        planta = await fetch_one("SELECT planta_id FROM planta WHERE nombre = %(n)s", {"n": f"Planta Aprobada {marca}"})
        assert planta is not None
        tur1 = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = %(c)s", {"c": "TUR-1"})
        assert tur1 is not None and float(tur1["sla_horas"]) == 4
    finally:
        await execute(
            "DELETE FROM maquina WHERE planta_id IN (SELECT planta_id FROM planta WHERE nombre LIKE %(p)s)",
            {"p": f"%{marca}%"},
        )
        await execute("DELETE FROM planta WHERE nombre LIKE %(p)s", {"p": f"%{marca}%"})


@pytest.mark.asyncio
async def test_crear_planta_aprobada_revalida_la_propuesta(db_pool):
    """La propuesta viene parseada del texto: se revalida con Pydantic. Una máquina sin
    código es propuesta inválida → no se crea nada."""
    antes = await fetch_one("SELECT COUNT(*) AS n FROM planta")

    salida = await crear_planta_aprobada(
        "Planta Inválida",
        [{"nombre": "Sin código"}],
        empresa_id=1,
        usuario_id=ADMIN_ID,
        rol="admin",
    )

    despues = await fetch_one("SELECT COUNT(*) AS n FROM planta")
    assert antes["n"] == despues["n"], "una propuesta inválida no crea nada"
    assert "no creé nada" in salida


# =============================================================================
# Endurecimiento de la Skill de plantas (HU-20 / CGBIDA-514, QA prod 05-11)
# =============================================================================


@pytest.mark.asyncio
async def test_proponer_planta_exige_ubicacion(db_pool):
    """QA 05-11: se creó una planta sin ubicación. En el chat la ubicación va ANTES de
    la propuesta (la regla del service/BD queda como propuesta al equipo)."""
    salida = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {"nombre": "Planta Sin Lugar", "maquinas": [{"nombre": "Turbina", "codigo": "TUR-9"}]}
    )
    assert "ubicación" in salida
    assert not salida.startswith(_PREFIJO_PROPUESTA_PLANTA)


@pytest.mark.asyncio
async def test_proponer_planta_permite_misma_ubicacion_con_nombre_distinto(client, ctx):
    """Regla de producto: dos plantas pueden compartir comuna si el nombre es distinto
    (p. ej. «Planta Norte» y «Planta Sur» en la misma comuna)."""
    ubicacion = f"Comuna {ctx['marca']}"
    r = await client.post(
        "/api/plantas/completa",
        headers=ctx["tokens"]["admin"],
        json={"nombre": f"Planta Original {ctx['marca']}", "ubicacion": ubicacion},
    )
    assert r.status_code == 201, r.text

    salida = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {"nombre": f"Planta Otra {ctx['marca']}", "ubicacion": ubicacion, "maquinas": []}
    )
    assert salida.startswith(_PREFIJO_PROPUESTA_PLANTA)
    assert ubicacion in salida


@pytest.mark.asyncio
async def test_proponer_planta_rechaza_mismo_nombre_y_ubicacion(client, ctx):
    """Solo se bloquea cuando coinciden ubicación Y nombre (dos homónimas confunden)."""
    ubicacion = f"Comuna {ctx['marca']}"
    nombre = f"Planta Original {ctx['marca']}"
    r = await client.post(
        "/api/plantas/completa",
        headers=ctx["tokens"]["admin"],
        json={"nombre": nombre, "ubicacion": ubicacion},
    )
    assert r.status_code == 201, r.text

    salida = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {"nombre": nombre, "ubicacion": ubicacion, "maquinas": []}
    )
    assert "mismo nombre" in salida
    assert not salida.startswith(_PREFIJO_PROPUESTA_PLANTA)


@pytest.mark.asyncio
async def test_proponer_planta_rechaza_disciplina_compuesta(db_pool):
    """QA 05-11: «Neumática / Mecánica» contaminó el catálogo de disciplinas. Una máquina
    pertenece a UNA disciplina; la secundaria va en el nombre."""
    salida = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {
            "nombre": "Planta Compuesta",
            "ubicacion": "San Miguel",
            "maquinas": [{"nombre": "Compresor híbrido", "codigo": "CB-1", "disciplina": "Neumática / Mecánica"}],
        }
    )
    assert "UNA sola" in salida
    assert "Neumática / Mecánica" in salida
    assert not salida.startswith(_PREFIJO_PROPUESTA_PLANTA)


@pytest.mark.asyncio
async def test_proponer_planta_cubre_quince_y_rechaza_dieceseis(db_pool):
    """QA 05-11: el tope por alta se subió de 8 a 15 (validado con el equipo). En 15 va,
    en 16 pide tandas."""
    lote = [{"nombre": f"Equipo {i}", "codigo": f"EQ-{i:02d}", "disciplina": "Mecánica"} for i in range(1, 16)]

    en_quince = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {"nombre": "Planta Grande", "ubicacion": "Chile", "maquinas": lote}
    )
    assert en_quince.startswith(_PREFIJO_PROPUESTA_PLANTA), "15 máquinas ES el tope: la propuesta va"

    lote.append({"nombre": "Equipo 16", "codigo": "EQ-16", "disciplina": "Mecánica"})
    en_dieceseis = await HERRAMIENTAS["proponer_planta_completa"].ainvoke(
        {"nombre": "Planta Grande", "ubicacion": "Chile", "maquinas": lote}
    )
    assert "el máximo por alta es 15" in en_dieceseis
    assert not en_dieceseis.startswith(_PREFIJO_PROPUESTA_PLANTA)

    planta = await fetch_one("SELECT planta_id FROM planta WHERE nombre = 'Planta Grande'")
    assert planta is None, "el tope es de propuesta: no se escribió nada acá"


def test_la_propuesta_planta_sin_maquinas_avisada():
    """QA 05-11: crear planta vacía es posible (el service lo permite), pero el usuario
    debe verlo explícito ANTES de confirmar."""
    texto = _texto_propuesta_planta("Planta Solo Casco", "Talagante", [])
    assert "SIN MÁQUINAS" in texto
    datos = _parsear_propuesta_planta(texto)
    assert datos is not None and datos["maquinas"] == []


# =============================================================================
# El candado en el grafo (mismo patrón que test_candado_ot.py)
# =============================================================================


class _LLMFalso:
    """Modelo guionado; para estos tests no debería invocarse (el gate corta antes)."""

    def __init__(self) -> None:
        self.llamadas: list[list] = []
        self.tools_vinculadas: list = []

    def bind_tools(self, tools):
        self.tools_vinculadas = list(tools)
        return self

    def with_retry(self, **_kwargs):
        return self

    async def ainvoke(self, mensajes):
        self.llamadas.append(list(mensajes))
        return AIMessage(content="esto no debería usarse")


def _propuesta_planta() -> str:
    return _texto_propuesta_planta(
        "Planta Candado",
        "Rancagua",
        [
            {"nombre": "Turbina 1", "codigo": "TUR-1", "disciplina": "Mecánica", "sla_horas": 4, "costo_inactividad_minuto": 30},
            {"nombre": "Turbina 2", "codigo": "TUR-2", "disciplina": "Mecánica"},
        ],
    )


def _entrada(mensajes) -> dict:
    return {
        "messages": mensajes,
        "empresa_id": 1,
        "pistas": [],
        "contexto": "",
        "fragmentos": 0,
    }


@pytest.fixture(autouse=True)
def _retrieval_aislado(monkeypatch):
    """El retrieval no corre en estos tests: el gate no depende de documentación."""

    async def vacio(*_a, **_k):
        return []

    monkeypatch.setattr(chat_graph, "search_chunks", vacio)


@pytest.mark.asyncio
async def test_el_grafo_no_crea_planta_sin_confirmacion(db_pool, monkeypatch):
    """Turno ambiguo tras la propuesta: ni un INSERT. La propuesta se re-emite idéntica."""
    modelo = _LLMFalso()
    grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

    estado = await grafo.ainvoke(_entrada([AIMessage(content=_propuesta_planta()), HumanMessage(content="mmm, no sé")]))

    final = estado["messages"][-1]
    assert final.content == _propuesta_planta(), "la propuesta se re-emite byte a byte"
    planta = await fetch_one("SELECT planta_id FROM planta WHERE nombre = 'Planta Candado'")
    assert planta is None, "sin el «sí» del usuario no se crea nada"


@pytest.mark.asyncio
async def test_el_grafo_crea_planta_con_confirmacion(db_pool, monkeypatch):
    """Con el «sí» del usuario, el gate ejecuta `crear_planta_aprobada` y la planta queda
    creada con sus máquinas."""
    modelo = _LLMFalso()
    grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

    try:
        estado = await grafo.ainvoke(_entrada([AIMessage(content=_propuesta_planta()), HumanMessage(content="sí, confirmo")]))

        final = estado["messages"][-1]
        assert "Planta «Planta Candado» creada con 2 máquina(s)" in final.content
        planta = await fetch_one("SELECT planta_id FROM planta WHERE nombre = 'Planta Candado'")
        assert planta is not None
        tur = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = 'TUR-1'")
        assert tur is not None and float(tur["sla_horas"]) == 4
    finally:
        await execute("DELETE FROM maquina WHERE codigo IN ('TUR-1', 'TUR-2')")
        await execute("DELETE FROM planta WHERE nombre = 'Planta Candado'")


@pytest.mark.asyncio
async def test_el_grafo_no_reintenta_tras_fallo_de_creacion(db_pool, monkeypatch):
    """CGBIDA-514.5: si la creación falla (planta ya existente), el gate informa el error
    y NO deja la propuesta pendiente. Un segundo «sí» no reintenta el write ni duplica."""
    marca = uuid.uuid4().hex[:8]
    nombre = f"Planta Repetida {marca}"
    codigo = f"TUR-{marca[:6]}"
    await execute(
        "INSERT INTO planta (empresa_id, nombre, ubicacion) VALUES (1, %(n)s, %(u)s)",
        {"n": nombre, "u": "Rancagua"},
    )
    try:
        propuesta = _texto_propuesta_planta(
            nombre,
            "Rancagua",
            [{"nombre": "Turbina 9", "codigo": codigo, "disciplina": "Mecánica"}],
        )
        modelo = _LLMFalso()
        grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

        estado = await grafo.ainvoke(
            _entrada([AIMessage(content=propuesta), HumanMessage(content="sí, confirmo")])
        )

        final = estado["messages"][-1]
        assert "Ya existe una planta llamada" in final.content
        assert final.content != propuesta, "el error reemplaza a la propuesta: no queda pendiente"
        assert not modelo.llamadas, "el gate resuelve el «sí» sin pasar por el modelo"

        # Segundo «sí»: sin propuesta pendiente, el gate no vuelve a escribir.
        estado2 = await grafo.ainvoke(
            {**estado, "messages": [*estado["messages"], HumanMessage(content="sí, confirmo")]}
        )
        assert "creada con" not in estado2["messages"][-1].content
        assert len(modelo.llamadas) == 1, "el turno sigue normal; no se re-ejecuta el gate"

        plantas = await fetch_one("SELECT COUNT(*) AS n FROM planta WHERE nombre = %(n)s", {"n": nombre})
        assert plantas["n"] == 1, "no se duplica la planta ni se reintenta el write"
    finally:
        await execute(
            "DELETE FROM maquina WHERE planta_id IN (SELECT planta_id FROM planta WHERE nombre = %(n)s)",
            {"n": nombre},
        )
        await execute("DELETE FROM planta WHERE nombre = %(n)s", {"n": nombre})


# =============================================================================
# El candado de los parámetros en el grafo (REGLA 10 ya no depende del modelo)
# =============================================================================


def _propuesta_parametros(actual: float = 6, nuevo: float = 8.0) -> str:
    return _texto_propuesta_parametros(
        {"nombre": "Bomba de pulpa KSB", "codigo": "BOM-001", "planta": "Planta Candado SLA"},
        {"sla_horas": actual, "costo_inactividad_minuto": 1000},
        {"sla_horas": nuevo},
    )


@pytest.mark.asyncio
async def test_el_grafo_no_cambia_parametros_sin_confirmacion(db_pool, monkeypatch):
    """Turno ambiguo tras la propuesta de parámetros: ni un UPDATE. La propuesta se
    re-emite idéntica. (El incidente del 31-10 en prod: el modelo escribió al instante;
    desde esta v2 el freno es el gate, no el prompt.)"""
    modelo = _LLMFalso()
    grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

    fila_antes = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = 'BOM-001'")
    estado = await grafo.ainvoke(
        _entrada([AIMessage(content=_propuesta_parametros()), HumanMessage(content="mmm, déjame pensarlo")])
    )

    final = estado["messages"][-1]
    assert final.content == _propuesta_parametros(), "la propuesta se re-emite byte a byte"
    fila = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = 'BOM-001'")
    assert fila["sla_horas"] == fila_antes["sla_horas"], "sin el «sí» del usuario no se escribe nada"


@pytest.mark.asyncio
async def test_el_grafo_cambia_parametros_con_confirmacion(db_pool, monkeypatch):
    """Con el «sí» del usuario, el gate ejecuta `actualizar_parametros_aprobada` y el SLA
    queda escrito (mensaje con antes → después)."""
    modelo = _LLMFalso()
    grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

    # El «antes» se lee de la base: el seed define el SLA inicial y hardcodearlo acoplaba
    # el test a una base concreta en vez de al comportamiento. Con el catálogo real
    # BOM-001 ya nace en 8 h, así que proponemos 10 h (sla_antes + 2).
    antes = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = 'BOM-001'")
    sla_antes = float(antes["sla_horas"])
    sla_nuevo = sla_antes + 2

    try:
        mensajes = [
            AIMessage(content=_propuesta_parametros(sla_antes, sla_nuevo)),
            HumanMessage(content="sí"),
        ]
        estado = await grafo.ainvoke(_entrada(mensajes))

        final = estado["messages"][-1]
        assert "Actualicé «Bomba de pulpa KSB»" in final.content
        assert f"{sla_antes:g} h → {sla_nuevo:g} h" in final.content
        fila = await fetch_one("SELECT sla_horas FROM maquina WHERE codigo = 'BOM-001'")
        assert float(fila["sla_horas"]) == sla_nuevo
    finally:
        await execute(
            "UPDATE maquina SET sla_horas = %(sla)s WHERE codigo = 'BOM-001'",
            {"sla": sla_antes},
        )


# =============================================================================
# QA 07-11: el turno con error de tool no queda pegado y la ubicación no se inventa
# =============================================================================


class _LLMGuionado:
    """Modelo que devuelve exactamente `respuesta`: sirve para ver si el grafo vuelca al
    modelo después de un error de tool (tras_tools), o para scripted de un tool_call y
    correr la ronda de tools real. Acepta `str` o `AIMessage` listo."""

    def __init__(self, respuesta: str | AIMessage) -> None:
        self.respuesta = respuesta
        self.llamadas: list[list] = []

    def bind_tools(self, _tools):
        return self

    def with_retry(self, **_kwargs):
        return self

    async def ainvoke(self, mensajes):
        self.llamadas.append(list(mensajes))
        if isinstance(self.respuesta, AIMessage):
            return self.respuesta
        return AIMessage(content=self.respuesta)


def _turno_con_tool_que_erro(content_tool: str, nombre: str = "proponer_planta_completa") -> list:
    """Historial de un turno donde el modelo ya llamó la tool y ella devolvió un error."""
    return [
        HumanMessage(content="crea la planta Bodega Norte con una balanza"),
        AIMessage(
            content="",
            tool_calls=[{"name": nombre, "args": {"nombre": "Bodega Norte"}, "id": "call-1", "type": "tool_call"}],
        ),
        ToolMessage(content=content_tool, name=nombre, tool_call_id="call-1"),
    ]


@pytest.mark.asyncio
async def test_el_grafo_conversa_cuando_la_tool_no_produce_propuesta(monkeypatch):
    """QA 07-11: la respuesta «Necesito la ubicación…» de la herramienta no cierra el
    turno de cabeza: vuelve al modelo, que pregunta en lenguaje natural."""
    modelo = _LLMGuionado("¿En qué comuna o dirección va la planta?")
    grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

    estado = await grafo.ainvoke(
        _entrada(_turno_con_tool_que_erro("Necesito la ubicación de la planta (comuna o dirección) antes de proponer el alta."))
    )

    final = estado["messages"][-1]
    assert final.content == "¿En qué comuna o dirección va la planta?", "el modelo responde; el turno no queda pegado al error"
    assert len(modelo.llamadas) == 1, "el error viajó al modelo como ToolMessage"


@pytest.mark.asyncio
async def test_el_grafo_termina_con_la_propuesta_exacta(db_pool):
    """La misma ruta con una propuesta válida sigue cortando el turno con el texto EXACTO
    de la tool: un parafraseo rompe el formato que el gate re-parsea."""
    datos = {
        "nombre": "Planta Propuesta XT",
        "ubicacion": "Ventarrón 889",
        "maquinas": [{"nombre": "Turbina", "codigo": "TRT-1", "disciplina": "Mecánica"}],
    }
    guion = AIMessage(
        content="", tool_calls=[{"name": "proponer_planta_completa", "args": datos, "id": "call-1", "type": "tool_call"}]
    )
    modelo = _LLMGuionado(guion)
    grafo = crear_grafo(empresa_id=1, llm=modelo, usuario_id=ADMIN_ID, rol="admin")

    estado = await grafo.ainvoke(_entrada([HumanMessage(content="crea la planta Propuesta XT en Ventarrón 889")]))

    final = estado["messages"][-1]
    propuesta = _texto_propuesta_planta(datos["nombre"], datos["ubicacion"], datos["maquinas"])
    assert final.content == propuesta, "la propuesta exacta termina el turno"
    assert len(modelo.llamadas) == 1, "el turno termina en la propuesta; no vuelve a generate"


@pytest.mark.asyncio
async def test_la_tool_no_propone_ubicaciones_que_nadie_dijo(db_pool):
    """QA 07-11: el modelo rellenaba el hueco con una ubicación inventada. Con la
    conversación a la vista, la tool rechaza una ubicación que ningún usuario escribió."""
    herramientas_test = {
        t.name: t
        for t in crear_tools(
            empresa_id=1,
            usuario_id=ADMIN_ID,
            rol="admin",
            habla_del_usuario=["crea la planta Nacional Places con dos turbina"],
        )
    }

    rechazo = await herramientas_test["proponer_planta_completa"].ainvoke(
        {"nombre": "Nacional Places", "ubicacion": "La Granja Invención", "maquinas": [{"nombre": "Turbina", "codigo": "INV-1"}]}
    )
    rechazo_minuscula = rechazo.lower()
    assert "no la invento" in rechazo_minuscula and "pregúntale" in rechazo_minuscula
    assert not rechazo.startswith(_PREFIJO_PROPUESTA_PLANTA)

    propuesta = await herramientas_test["proponer_planta_completa"].ainvoke(
        {"nombre": "Nacional Places", "ubicacion": "Nacional Places", "maquinas": [{"nombre": "Turbina", "codigo": "INV-1"}]}
    )
    assert propuesta.startswith(_PREFIJO_PROPUESTA_PLANTA), "la ubicación dicha por el usuario sí pasa"


# =============================================================================
# Consultas de topología y cantidad de plantas (problema del conteo en el chat)
# =============================================================================


@pytest.mark.parametrize(
    ("consulta", "es_general"),
    [
        ("", True),
        ("todas", True),
        ("todas las plantas", True),
        ("plantas", True),
        ("topologia", True),
        ("topología", True),
        ("la topologia", True),
        ("topologia de la empresa", True),
        ("cuantas plantas", True),
        ("cuántas plantas tiene la empresa", True),
        ("general", True),
        ("resumen", True),
        ("Chancado Primario", False),
        ("Molienda SAG", False),
        ("Planta de Vapor", False),
        ("Planta Skill 123", False),
    ],
)
def test_es_consulta_todas_plantas(consulta: str, es_general: bool):
    """Detecta si el usuario/LLM pide la topología general o una planta específica."""
    from barb.services.ai_tools import _es_consulta_todas_plantas

    assert _es_consulta_todas_plantas(consulta) is es_general


@pytest.mark.asyncio
async def test_listar_maquinas_planta_retorna_total_exacto(monkeypatch):
    """listar_maquinas_planta debe reportar el total exacto de plantas tanto con '' como con 'todas'/'plantas'."""
    from barb.services import ai_tools

    plantas_mock = [
        {"nombre": "Chancado Primario", "ubicacion": "Calama", "n": 2},
        {"nombre": "Molienda SAG", "ubicacion": "Calama", "n": 2},
    ]

    async def mock_fetch_all(sql, params=None):
        return plantas_mock

    monkeypatch.setattr(ai_tools, "fetch_all", mock_fetch_all)

    tools = {t.name: t for t in crear_tools(empresa_id=1, usuario_id=ADMIN_ID, rol="gerente")}
    tool = tools["listar_maquinas_planta"]

    for arg in ["", "todas", "plantas", "topologia", "cuántas plantas"]:
        salida = await tool.ainvoke({"planta": arg})
        assert "Plantas de tu empresa (2 en total):" in salida
        assert "Chancado Primario" in salida
        assert "Molienda SAG" in salida


@pytest.mark.asyncio
async def test_listar_maquinas_planta_sin_plantas(monkeypatch):
    """Con 0 plantas registradas debe indicarlo explícitamente."""
    from barb.services import ai_tools

    async def mock_fetch_all(sql, params=None):
        return []

    monkeypatch.setattr(ai_tools, "fetch_all", mock_fetch_all)

    tools = {t.name: t for t in crear_tools(empresa_id=1, usuario_id=ADMIN_ID, rol="gerente")}
    salida = await tools["listar_maquinas_planta"].ainvoke({"planta": ""})
    assert "0 plantas" in salida


def test_prompt_instruye_listar_maquinas_planta_para_topologia():
    """El prompt del sistema debe instruir explícitamente usar listar_maquinas_planta para topología y conteo."""
    from barb.services.chat_graph import _prompt_sistema

    prompt = _prompt_sistema("(sin contexto)", puede_crear_ot=False)
    assert "listar_maquinas_planta" in prompt
    assert "cuántas plantas tiene la empresa" in prompt
    assert "NUNCA inventes ni adivines la cantidad de plantas" in prompt

