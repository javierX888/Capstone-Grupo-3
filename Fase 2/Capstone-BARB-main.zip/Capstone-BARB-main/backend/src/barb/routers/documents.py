"""
Gestión de la documentación de cada empresa (fuente única de conocimiento del chat IA).

- Cada documento pertenece a UNA empresa (documento.empresa_id).
- Un usuario de empresa solo lista/sube/edita/elimina documentos de su empresa.
- El super_usuario puede operar sobre cualquier empresa (?empresa_id= / campo del form).
- Al subir un archivo se extrae su texto y se indexa en `documento_chunk`; el chat
  solo consulta documentos con `activo = TRUE`.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from pydantic import BaseModel, Field

from barb.core.db import fetch_all, fetch_one, transaction
from barb.core.permissions import (
    ROL_SUPER,
    empresa_obligatoria,
    get_sesion_actual,
    require_action,
    require_route,
    resolver_empresa,
)
from barb.services import document_service as docs
from barb.services.document_storage import StorageError, delete_document_file, save_document_file

logger = logging.getLogger("barb.documents_router")

router = APIRouter()

_DOC_SELECT = """
    SELECT d.documento_id, d.empresa_id, e.nombre AS empresa_nombre, d.title, d.notes, d.original_name,
           d.content_type, d.size_bytes, d.chunks_indexed, d.activo, d.created_at,
           u.nombre AS subido_por, d.maquina_id, m.nombre AS maquina_nombre, m.codigo AS maquina_codigo
    FROM documento d
    JOIN empresa e ON e.empresa_id = d.empresa_id
    LEFT JOIN maquina m ON m.maquina_id = d.maquina_id
    LEFT JOIN usuario u ON u.usuario_id = d.usuario_id
"""


def _serialize(r: dict) -> dict:
    return {
        "id": int(r["documento_id"]),
        "empresa_id": int(r["empresa_id"]),
        "empresa_nombre": r["empresa_nombre"],
        "title": r["title"],
        "notes": r["notes"],
        "original_name": r["original_name"],
        "content_type": r["content_type"],
        "size_bytes": int(r["size_bytes"] or 0),
        "chunks_indexed": int(r["chunks_indexed"] or 0),
        "activo": bool(r["activo"]),
        "created_at": r["created_at"].isoformat() if r["created_at"] else None,
        "subido_por": r["subido_por"],
        "maquina_id": int(r["maquina_id"]) if r["maquina_id"] is not None else None,
        "maquina_nombre": r["maquina_nombre"],
        "maquina_codigo": r["maquina_codigo"],
    }


class DocumentUpdateRequest(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=255)
    notes: str | None = None
    activo: bool | None = None
    # Ausente = no cambia; int = asigna máquina; null = desvincula.
    maquina_id: int | None = None


async def _validar_maquina_de_empresa(maquina_id: int, empresa_id: int) -> None:
    """404 si la máquina no existe o su planta es de otra empresa (no se revela su existencia)."""
    row = await fetch_one(
        "SELECT 1 FROM maquina m JOIN planta p ON p.planta_id = m.planta_id"
        " WHERE m.maquina_id = %(id)s AND p.empresa_id = %(empresa_id)s",
        {"id": maquina_id, "empresa_id": empresa_id},
    )
    if not row:
        raise HTTPException(status_code=404, detail="Máquina no encontrada.")


async def _documento_visible(documento_id: int, sesion: dict) -> dict:
    """Carga el documento; 404 si no existe o es de otra empresa (no se revela su existencia)."""
    row = await fetch_one(_DOC_SELECT + " WHERE d.documento_id = %(id)s", {"id": documento_id})
    if not row or (sesion["rol"] != ROL_SUPER and row["empresa_id"] != sesion["empresa_id"]):
        raise HTTPException(status_code=404, detail="Documento no encontrado.")
    return row


@router.get("/api/documents", dependencies=[Depends(require_route("documentos", solo_lectura=True))])
@router.get("/api/documentos", dependencies=[Depends(require_route("documentos", solo_lectura=True))])
async def list_documents(empresa_id: int | None = Query(default=None), sesion: dict = Depends(get_sesion_actual)):
    scope = resolver_empresa(sesion, empresa_id)
    rows = await fetch_all(
        _DOC_SELECT
        + " WHERE (%(empresa_id)s::int IS NULL OR d.empresa_id = %(empresa_id)s)"
        + " ORDER BY d.created_at DESC, d.documento_id DESC",
        {"empresa_id": scope},
    )
    return [_serialize(r) for r in rows]


@router.post("/api/documents", status_code=201, dependencies=[Depends(require_action("subir_documentos"))])
@router.post("/api/documentos", status_code=201, dependencies=[Depends(require_action("subir_documentos"))])
async def upload_document(
    file: UploadFile = File(...),
    title: str = Form(default=""),
    notes: str = Form(default=""),
    empresa_id: int | None = Form(default=None),  # solo lo respeta el super_usuario
    maquina_id: int | None = Form(default=None),
    sesion: dict = Depends(get_sesion_actual),
):
    empresa = empresa_obligatoria(sesion, empresa_id)
    if maquina_id is not None:
        await _validar_maquina_de_empresa(maquina_id, empresa)  # antes de leer/guardar nada
    original_name = Path(file.filename or "documento").name  # sin rutas del cliente

    data = await file.read(docs.MAX_BYTES + 1)
    if len(data) > docs.MAX_BYTES:
        raise HTTPException(status_code=413, detail=f"El archivo supera el máximo de {docs.MAX_BYTES // (1024 * 1024)} MB.")
    if not data:
        raise HTTPException(status_code=422, detail="El archivo está vacío.")

    # Extracción/fragmentación son CPU-bound: fuera del event loop.
    text = await asyncio.to_thread(docs.extract_text, original_name, data)
    chunks = await asyncio.to_thread(docs.split_chunks, text)

    existe = await fetch_one("SELECT empresa_id FROM empresa WHERE empresa_id = %(id)s", {"id": empresa})
    if not existe:
        raise HTTPException(status_code=404, detail="La empresa indicada no existe.")

    file_id = uuid.uuid4().hex
    stored_name = f"{file_id}{Path(original_name).suffix.lower()}"

    try:
        await save_document_file(empresa, stored_name, data, content_type=file.content_type)
        async with transaction() as cur:
            await cur.execute(
                """
                INSERT INTO documento (empresa_id, usuario_id, maquina_id, title, notes, original_name, stored_name,
                                       file_id, content_type, size_bytes, chunks_indexed)
                VALUES (%(empresa_id)s, %(usuario_id)s, %(maquina_id)s, %(title)s, %(notes)s, %(original_name)s,
                        %(stored_name)s, %(file_id)s, %(content_type)s, %(size)s, %(chunks)s)
                RETURNING documento_id
                """,
                {
                    "empresa_id": empresa,
                    "usuario_id": sesion["usuario_id"],
                    "maquina_id": maquina_id,
                    "title": (title or "").strip() or Path(original_name).stem,
                    "notes": (notes or "").strip() or None,
                    "original_name": original_name,
                    "stored_name": stored_name,
                    "file_id": file_id,
                    "content_type": file.content_type,
                    "size": len(data),
                    "chunks": len(chunks),
                },
            )
            documento_id = int((await cur.fetchone())["documento_id"])
            await docs.index_chunks(cur, documento_id, empresa, chunks)
    except StorageError as e:
        logger.error("Almacenamiento externo no disponible: %s", e)
        raise HTTPException(
            status_code=503,
            detail="El almacenamiento de documentos no está disponible. Intenta más tarde.",
        ) from e
    except Exception as e:
        # No dejar archivos huérfanos si falló la BD tras subir el archivo.
        try:
            await delete_document_file(empresa, stored_name)
        except Exception:
            logger.exception("No se pudo revertir el archivo subido: %s", stored_name)
        logger.exception("Error al guardar documento")
        raise HTTPException(status_code=500, detail="Error interno al guardar el documento.") from e

    return _serialize(await fetch_one(_DOC_SELECT + " WHERE d.documento_id = %(id)s", {"id": documento_id}))


@router.patch("/api/documents/{documento_id}", dependencies=[Depends(require_action("subir_documentos"))])
@router.patch("/api/documentos/{documento_id}", dependencies=[Depends(require_action("subir_documentos"))])
async def update_document(documento_id: int, payload: DocumentUpdateRequest, sesion: dict = Depends(get_sesion_actual)):
    doc = await _documento_visible(documento_id, sesion)
    changes = payload.model_dump(exclude_unset=True)
    if changes.get("maquina_id") is not None:
        await _validar_maquina_de_empresa(changes["maquina_id"], int(doc["empresa_id"]))
    if changes:
        sets = ", ".join(f"{col} = %({col})s" for col in changes)  # columnas: lista cerrada del modelo
        async with transaction() as cur:
            await cur.execute(f"UPDATE documento SET {sets} WHERE documento_id = %(_id)s", {**changes, "_id": documento_id})
    return _serialize(await fetch_one(_DOC_SELECT + " WHERE d.documento_id = %(id)s", {"id": documento_id}))


@router.delete("/api/documents/{documento_id}", status_code=204, dependencies=[Depends(require_action("eliminar_documentos"))])
@router.delete("/api/documentos/{documento_id}", status_code=204, dependencies=[Depends(require_action("eliminar_documentos"))])
async def delete_document(documento_id: int, sesion: dict = Depends(get_sesion_actual)):
    row = await _documento_visible(documento_id, sesion)
    stored = await fetch_one("SELECT stored_name FROM documento WHERE documento_id = %(id)s", {"id": documento_id})
    async with transaction() as cur:
        # documento_chunk se elimina en cascada.
        await cur.execute("DELETE FROM documento WHERE documento_id = %(id)s", {"id": documento_id})
    if stored:
        try:
            await delete_document_file(int(row["empresa_id"]), stored["stored_name"])
        except StorageError:
            # El documento ya se eliminó de la BD; el archivo huérfano se limpia
            # manualmente o con el ciclo de vida del storage. No debe bloquear el 204.
            logger.exception("Archivo físico no se pudo eliminar: %s", stored["stored_name"])
    return None
