from __future__ import annotations

import asyncio
import base64
import binascii
import json
import logging
import re
import uuid
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field, field_validator
from sse_starlette.sse import EventSourceResponse

from barb.core.config import settings
from barb.core.rate_limit import chat_rate_limiter
from barb.core.security import get_current_user
from barb.core.token_limit import estimate_tokens, token_limiter
from barb.schemas.chat import (
    ChatMessage,
    DeleteSessionResponse,
    SessionDetailResponse,
    SessionListItem,
    SessionListResponse,
)
from barb.services import chat_repository
from barb.services.chat_graph import astream_respuesta
from barb.services.document_service import format_context, search_chunks
from barb.services.llm_service import (
    MULTIMODAL_IMAGE_TOKENS,
    NO_DOCS_ANSWER,
    create_multimodal_chain,
)

logger = logging.getLogger("barb.chat")

# Persistencias en vuelo. Se guardan referencias para que el recolector no se lleve una
# escritura que quedó en segundo plano tras una desconexión del cliente.
_PERSISTENCIAS_EN_VUELO: set[asyncio.Task] = set()


async def _persistir_pese_a_la_cancelacion(
    session_id: str, usuario_id: int, nuevos: list[dict]
) -> None:
    """
    Guarda la conversación aunque el cliente ya se haya ido.

    Cuando el navegador corta el stream, Starlette cancela la tarea que lo sirve y el
    `await` del `finally` moría a mitad de la escritura: se perdía el turno y, peor, la
    conexión volvía al pool en estado ACTIVE (psycopg la descartaba con «another command
    is already in progress»). La escritura va en una tarea propia y se espera con `shield`,
    así termina sola y libera la conexión limpia.
    """
    tarea: asyncio.Task = asyncio.create_task(
        chat_repository.append_messages(session_id, usuario_id, nuevos)
    )
    _PERSISTENCIAS_EN_VUELO.add(tarea)
    tarea.add_done_callback(_PERSISTENCIAS_EN_VUELO.discard)
    await asyncio.shield(tarea)

router = APIRouter(prefix="/api/chat", tags=["chat"])


class ChatRequest(BaseModel):
    session_id: str | None = None
    message: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="Mensaje del usuario (1 a 2000 caracteres).",
    )
    # HU-23. Ausente = conserva la máquina de la sesión; int = fija/cambia; null = desvincula.
    # La diferencia entre ausente y null se lee con `model_fields_set`.
    maquina_id: int | None = None
    # CGBIDA-551: Idioma del usuario ('es' | 'en')
    locale: str = "es"


async def _resolver_maquina_pedida(request, empresa_id: int) -> tuple[bool, dict | None]:
    """Interpreta `maquina_id` del request: `(cambia, ficha)`.

    404 si la máquina no existe o es de otra empresa. Se llama ANTES del rate limit y del límite
    de tokens: un request inválido no consume cuota.
    """
    if "maquina_id" not in request.model_fields_set:
        return False, None
    if request.maquina_id is None:
        return True, None
    maquina = await chat_repository.get_maquina_de_empresa(request.maquina_id, empresa_id)
    if maquina is None:
        raise HTTPException(status_code=404, detail="Máquina no encontrada.")
    return True, maquina


async def _maquina_de_la_sesion(existing: dict, empresa_id: int) -> dict | None:
    """Ficha de la máquina vinculada a una sesión existente (None si no tiene o ya no existe)."""
    mid = existing.get("maquina_id")
    if mid is None:
        return None
    return await chat_repository.get_maquina_de_empresa(int(mid), empresa_id)


def _now_ms() -> int:
    return int(datetime.now(UTC).timestamp() * 1000)


@router.post("/stream")
async def stream_chat(
    request: ChatRequest,
    user: dict = Depends(get_current_user),
):
    user_id = int(user["id"])
    # Aislamiento: un usuario de empresa SIEMPRE consulta la documentación de su empresa.
    # get_current_user ya excluye al super_usuario; esta guarda cubre cualquier usuario sin empresa.
    if user["role"] == "super_usuario" or user["empresa_id"] is None:
        raise HTTPException(status_code=403, detail="Tu perfil no tiene acceso a DocChat.")
    empresa_id = int(user["empresa_id"])

    cambia_maquina, maquina_pedida = await _resolver_maquina_pedida(request, empresa_id)

    chat_rate_limiter.check(str(user_id))

    token_limiter.check(str(user_id))

    if request.session_id:
        try:
            uuid.UUID(request.session_id)
        except (ValueError, TypeError):
            raise HTTPException(
                status_code=422,
                detail="session_id debe ser un UUID válido.",
            )

        existing = await chat_repository.get_session(request.session_id, user_id)
        if not existing:
            raise HTTPException(
                status_code=404,
                detail="Sesión no encontrada o no te pertenece.",
            )
        session_id = request.session_id
        history = await chat_repository.load_messages(
            session_id, user_id, limite=settings.chat_memory_window
        )
        if cambia_maquina:
            await chat_repository.set_maquina(session_id, user_id, maquina_pedida)
            maquina_activa = maquina_pedida
        else:
            maquina_activa = await _maquina_de_la_sesion(existing, empresa_id)
    else:
        session_id = await chat_repository.create_session(
            usuario_id=user_id,
            empresa_id=empresa_id,
            primer_mensaje=request.message,
            maquina=maquina_pedida,
        )
        history = []
        maquina_activa = maquina_pedida

    # --- RAG + Skills: el grafo de LangGraph hace retrieval, generación y tools ---
    # Las dos pistas siguientes resuelven preguntas de seguimiento («¿y el torque?»): se
    # incluye el último mensaje del usuario y también el último del ASISTENTE, porque los
    # turnos con imagen dejan ahí el equipo identificado («es un chancador de mandíbulas»).
    previous_user_msgs = [m.get("content", "") for m in history if m.get("role") == "user"][-1:]
    previous_assistant_msgs = [m.get("content", "") for m in history if m.get("role") == "assistant"][-1:]
    pistas_rag = [request.message, *previous_user_msgs, *previous_assistant_msgs]
    input_tokens = estimate_tokens(request.message)

    async def event_generator():
        output_chars = 0
        assistant_chunks: list[str] = []

        try:
            yield {
                "event": "session",
                "data": json.dumps({"session_id": session_id}),
            }

            # HU-04 Fase 2: el motor es un grafo (retrieve -> generate -> tools -> generate).
            # El streaming sigue igual: el grafo emite los deltas del nodo `generate`.
            stream = astream_respuesta(
                empresa_id=empresa_id,
                mensaje=request.message,
                historial=history,
                pistas=pistas_rag,
                # Identidad para las tools de acción (`crear_ot`): decide qué técnico
                # recibe la OT y quién figura como creador. No viaja al modelo.
                usuario_id=user_id,
                rol=user.get("role"),
                maquina=maquina_activa,
            )

            async for chunk in stream:
                if chunk:
                    output_chars += len(chunk)
                    assistant_chunks.append(chunk)
                    yield {
                        "event": "token",
                        "data": json.dumps({"text": chunk}),
                    }

            # Red de seguridad: si el grafo no produjo texto (modelo mudo o sin contexto ni
            # herramientas), se responde lo mismo de siempre en vez de dejar el chat vacío.
            if not assistant_chunks:
                assistant_chunks.append(NO_DOCS_ANSWER)
                output_chars += len(NO_DOCS_ANSWER)
                yield {
                    "event": "token",
                    "data": json.dumps({"text": NO_DOCS_ANSWER}),
                }

            yield {"event": "done", "data": "{}"}

        except Exception as e:
            logger.exception("Error en chat stream (session_id=%s)", session_id)
            yield {
                "event": "error",
                "data": json.dumps({"code": "internal_error", "message": str(e)}),
            }

        finally:
            # La contabilidad va primero: si el cliente se fue, no queremos saltearla por
            # una cancelación en la escritura.
            output_tokens = max(0, output_chars // 4)
            token_limiter.add(str(user_id), input_tokens + output_tokens)

            try:
                ts = _now_ms()
                nuevos = [
                    {"role": "user", "content": request.message, "timestamp": ts},
                    {
                        "role": "assistant",
                        "content": "".join(assistant_chunks),
                        "timestamp": ts + 1,
                    },
                ]
                await _persistir_pese_a_la_cancelacion(session_id, user_id, nuevos)
            except asyncio.CancelledError:
                # El cliente cortó el stream: la escritura termina en segundo plano.
                logger.info(
                    "Chat: cliente desconectado; la conversación se guarda en segundo plano "
                    "(session_id=%s)",
                    session_id,
                )
                raise
            except Exception:
                logger.exception(
                    "No se pudo persistir la conversación session_id=%s", session_id
                )

    return EventSourceResponse(event_generator())


# =============================================================================
# Chat multimodal (HU-05): POST /api/chat/multimedia
# Contrato: docs/contrato_api_chat_multimedia.md · Diseño: docs/MULTIMODAL_ARCHITECTURE.md
# =============================================================================

# Formatos permitidos por el contrato (D4). muse-glimmer los soporta vía data URL
# (verificado contra NIM: jpeg/png/webp responden en español).
ALLOWED_IMAGE_MIME = {"image/jpeg", "image/png", "image/webp"}

_DATA_URL_RE = re.compile(r"^data:([\w./+-]+);base64,(.*)$", re.DOTALL)

# 400 del contrato: sin imagen o mensaje vacío (detalle exacto del contrato).
_MULTIMEDIA_FALTA_INPUT = "Debes adjuntar una imagen y una pregunta."


class MultimediaRequest(BaseModel):
    session_id: str | None = None
    # El vacío se rechaza con 400 en el endpoint (detalle del contrato que combina
    # imagen+pregunta), no con min_length=1 como en el stream.
    message: str = Field(
        ...,
        max_length=2000,
        description="Pregunta del usuario sobre la imagen (1 a 2000 caracteres).",
    )
    # HU-23: misma semántica que en `ChatRequest` (ausente = conserva, int = fija/cambia, null = desvincula).
    maquina_id: int | None = None
    # CGBIDA-551: Idioma del usuario ('es' | 'en')
    locale: str = "es"
    image_base64: str = Field(
        ...,
        description="Imagen como data URL: data:image/{jpeg|png|webp};base64,... (≤ 5 MB decodificada).",
    )

    @field_validator("image_base64")
    @classmethod
    def _formato_de_imagen_permitido(cls, v: str) -> str:
        """Formato de imagen → 422 con array de errores Pydantic (contrato)."""
        m = _DATA_URL_RE.match(v)
        if m and m.group(1) not in ALLOWED_IMAGE_MIME:
            raise ValueError(
                f"Formato de imagen no permitido ({m.group(1)}). "
                f"Solo se aceptan: {', '.join(sorted(ALLOWED_IMAGE_MIME))}."
            )
        return v


def _validate_image(image_base64: str) -> None:
    """Valida estructura del data URL (400) y tamaño decodificado (413).

    El tamaño se mide sobre los bytes DECODIFICADOS (D4): el base64 infla ~33%
    en tránsito, por eso el límite no aplica sobre el string.
    """
    m = _DATA_URL_RE.match(image_base64)
    if not m:
        raise HTTPException(status_code=400, detail=_MULTIMEDIA_FALTA_INPUT)

    # Tolerante a saltos de línea en el base64 (encoders que hacen wrap).
    payload = "".join(m.group(2).split())
    if not payload:
        raise HTTPException(status_code=400, detail=_MULTIMEDIA_FALTA_INPUT)
    try:
        raw = base64.b64decode(payload + "=" * (-len(payload) % 4), validate=True)
    except (binascii.Error, ValueError):
        raise HTTPException(status_code=400, detail=_MULTIMEDIA_FALTA_INPUT) from None

    max_bytes = settings.multimodal_max_image_mb * 1024 * 1024
    if len(raw) > max_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"La imagen supera el máximo de {settings.multimodal_max_image_mb} MB.",
        )


@router.post("/multimedia")
async def stream_multimedia_chat(
    request: MultimediaRequest,
    user: dict = Depends(get_current_user),
):
    """
    Análisis de imágenes en el chat IA (HU-05, CGBIDA-276/277).

    La imagen viaja como data URL base64, se usa en memoria para la respuesta
    y NO se persiste (D2): el historial guarda solo el texto del turno, igual
    que cualquier otra conversación. Reutiliza la infra del stream textual:
    JWT, rate limit, límite diario de tokens y los mismos eventos SSE.
    """
    # Feature apagada sin modelo/key (patrón 503 de documents.py).
    if not settings.multimodal_configurado:
        raise HTTPException(
            status_code=503,
            detail="El análisis de imágenes no está disponible (MULTIMODAL_MODEL).",
        )

    user_id = int(user["id"])
    # Aislamiento + RBAC idéntico al stream textual (alineado tras la HU-12,
    # PR #23): get_current_user ya excluye al super_usuario; esta guarda cubre
    # cualquier usuario sin empresa. El DocChat completo comparte esta política.
    if user["role"] == "super_usuario" or user["empresa_id"] is None:
        raise HTTPException(status_code=403, detail="Tu perfil no tiene acceso a DocChat.")
    empresa_id = int(user["empresa_id"])

    # Validaciones del payload ANTES del rate limit: un request inválido no debe
    # consumir cuota (el frontend igual valida antes de enviar; el backend
    # revalida — nunca confiar solo en el cliente).
    if not request.message.strip():
        raise HTTPException(status_code=400, detail=_MULTIMEDIA_FALTA_INPUT)
    _validate_image(request.image_base64)
    cambia_maquina, maquina_pedida = await _resolver_maquina_pedida(request, empresa_id)

    chat_rate_limiter.check(str(user_id))

    token_limiter.check(str(user_id))

    if request.session_id:
        try:
            uuid.UUID(request.session_id)
        except (ValueError, TypeError):
            raise HTTPException(
                status_code=422,
                detail="session_id debe ser un UUID válido.",
            ) from None

        existing = await chat_repository.get_session(request.session_id, user_id)
        if not existing:
            raise HTTPException(
                status_code=404,
                detail="Sesión no encontrada o no te pertenece.",
            )
        session_id = request.session_id
        history = await chat_repository.load_messages(
            session_id, user_id, limite=settings.chat_memory_window
        )
        if cambia_maquina:
            await chat_repository.set_maquina(session_id, user_id, maquina_pedida)
            maquina_activa = maquina_pedida
        else:
            maquina_activa = await _maquina_de_la_sesion(existing, empresa_id)
    else:
        session_id = await chat_repository.create_session(
            usuario_id=user_id,
            empresa_id=empresa_id,
            primer_mensaje=request.message,
            maquina=maquina_pedida,
        )
        history = []
        maquina_activa = maquina_pedida

    # RAG ligero (D5 v1.1, review de la HU-05): fragmentos de la documentación
    # ACTIVA de la empresa que coincidan con la pregunta. El turno multimodal
    # responde con la imagen Y con los manuales cuando aplican; el prompt exige
    # etiquetar el origen (identificación visual vs documentación citada).
    # Se incluye el mensaje previo del asistente para que los turnos con imagen
    # aporten su contexto ("es un chancador de mandíbulas") a la búsqueda.
    previous_user_msgs = [m.get("content", "") for m in history if m.get("role") == "user"][-1:]
    previous_assistant_msgs = [m.get("content", "") for m in history if m.get("role") == "assistant"][-1:]
    # HU-04 Fase 1 — misma búsqueda semántica con fallback léxico que el chat textual:
    # los manuales se buscan por significado también cuando la pregunta trae una imagen.
    pistas = [request.message, *previous_user_msgs, *previous_assistant_msgs]
    if maquina_activa:
        # HU-23: los documentos de la máquina primero, completando con los generales de la empresa.
        chunks_rag = await search_chunks(empresa_id, *pistas, maquina_id=maquina_activa["maquina_id"])
    else:
        chunks_rag = await search_chunks(empresa_id, *pistas)
    context = format_context(chunks_rag) if chunks_rag else ""

    chain = create_multimodal_chain()
    # Contabilidad de tokens (D6): el presupuesto visual de la imagen (~4096)
    # cuenta contra el límite diario del usuario. El contexto inyectado no se
    # cuenta, igual que en el stream textual.
    input_tokens = estimate_tokens(request.message) + MULTIMODAL_IMAGE_TOKENS

    async def event_generator():
        output_chars = 0
        assistant_chunks: list[str] = []

        try:
            yield {
                "event": "session",
                "data": json.dumps({"session_id": session_id}),
            }

            stream = chain.astream(
                {
                    "input": request.message,
                    "history": history,
                    "image": request.image_base64,
                    "context": context,
                    "maquina": maquina_activa,
                }
            )

            async for chunk in stream:
                if chunk:
                    output_chars += len(chunk)
                    assistant_chunks.append(chunk)
                    yield {
                        "event": "token",
                        "data": json.dumps({"text": chunk}),
                    }

            yield {"event": "done", "data": "{}"}

        except Exception as e:
            logger.exception("Error en chat multimedia (session_id=%s)", session_id)
            yield {
                "event": "error",
                "data": json.dumps({"code": "internal_error", "message": str(e)}),
            }

        finally:
            output_tokens = max(0, output_chars // 4)
            token_limiter.add(str(user_id), input_tokens + output_tokens)

            try:
                ts = _now_ms()
                # D2: se persiste SOLO el texto del turno; la imagen no se guarda (v1). Solo se deja
                # la marca `has_image` (HU-23), nunca el base64 ni una URL.
                nuevos = [
                    {"role": "user", "content": request.message, "timestamp": ts, "has_image": True},
                    {
                        "role": "assistant",
                        "content": "".join(assistant_chunks),
                        "timestamp": ts + 1,
                    },
                ]
                await _persistir_pese_a_la_cancelacion(session_id, user_id, nuevos)
            except asyncio.CancelledError:
                logger.info(
                    "Chat multimodal: cliente desconectado; la conversación se guarda en "
                    "segundo plano (session_id=%s)",
                    session_id,
                )
                raise
            except Exception:
                logger.exception(
                    "No se pudo persistir la conversación session_id=%s", session_id
                )

    return EventSourceResponse(event_generator())


# =============================================================================
# Listado / consulta / borrado de conversaciones (CGBIDA-254, 255, 256)
# =============================================================================

@router.get("/sessions", response_model=SessionListResponse)
async def list_sessions(
    user: dict = Depends(get_current_user),
    limit: int = Query(20, ge=1, le=100, description="Tamaño de página (1-100)"),
    offset: int = Query(0, ge=0, description="Desplazamiento"),
):
    """
    Lista las conversaciones del usuario autenticado, ordenadas por
    `saved_at DESC`. Incluye metadatos (técnico, equipo, disciplina) para
    la tabla de historial.
    """
    user_id = int(user["id"])
    sessions = await chat_repository.list_by_user(user_id, limit=limit, offset=offset)

    items = [
        SessionListItem(
            session_id=str(s["session_id"]),
            titulo=str(s["titulo"]),
            saved_at=s["saved_at"],
            message_count=int(s["message_count"]),
            saved_by=s.get("saved_by"),
            machine_name=s.get("machine_name"),
            discipline=s.get("discipline"),
            plant_name=s.get("plant_name"),
        )
        for s in sessions
    ]
    return SessionListResponse(sessions=items, total=len(items))


@router.get("/sessions/{session_id}", response_model=SessionDetailResponse)
async def get_session_detail(
    session_id: str,
    user: dict = Depends(get_current_user),
):
    """
    Devuelve el historial completo de una conversación.

    Valida que el `session_id` sea un UUID y que pertenezca al usuario
    autenticado (CGBIDA-257).
    """
    user_id = int(user["id"])

    # Validar formato UUID
    try:
        uuid.UUID(session_id)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=422,
            detail="session_id debe ser un UUID válido.",
        )

    # Verificar ownership + existencia
    session = await chat_repository.get_session(session_id, user_id)
    if not session:
        raise HTTPException(
            status_code=404,
            detail="Sesión no encontrada o no te pertenece.",
        )

    messages_raw = await chat_repository.load_messages(session_id, user_id)
    messages = [
        ChatMessage(
            role=str(m.get("role", "")),
            content=str(m.get("content", "")),
            timestamp=int(m["timestamp"]) if m.get("timestamp") is not None else None,
            has_image=bool(m.get("has_image", False)),
        )
        for m in messages_raw
    ]

    return SessionDetailResponse(
        session_id=str(session["session_id"]),
        titulo=str(session["titulo"]),
        saved_at=session["saved_at"],
        messages=messages,
        maquina_id=session.get("maquina_id"),
        machine_name=session.get("machine_name"),
    )


@router.delete("/sessions/{session_id}", response_model=DeleteSessionResponse)
async def delete_session(
    session_id: str,
    user: dict = Depends(get_current_user),
):
    """
    Elimina una conversación del usuario autenticado.

    Valida formato UUID, existencia y ownership. Si la sesión no existe o
    no pertenece al usuario, devuelve 404 (no revela si existe para otro).
    """
    user_id = int(user["id"])

    # Validar formato UUID
    try:
        uuid.UUID(session_id)
    except (ValueError, TypeError):
        raise HTTPException(
            status_code=422,
            detail="session_id debe ser un UUID válido.",
        )

    deleted = await chat_repository.delete_session(session_id, user_id)
    if not deleted:
        raise HTTPException(
            status_code=404,
            detail="Sesión no encontrada o no te pertenece.",
        )

    return DeleteSessionResponse(deleted=True, session_id=session_id)