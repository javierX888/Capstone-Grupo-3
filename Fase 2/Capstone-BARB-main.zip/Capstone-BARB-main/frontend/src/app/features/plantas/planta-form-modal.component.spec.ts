import { TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';

import { Plant, PlantaCompletaResponse } from '../../core/models';
import { CatalogService } from '../../core/services/catalog.service';
import { ToastService } from '../../core/services/toast.service';
import { PlantaFormModalComponent } from './planta-form-modal.component';

/**
 * Tests del alta masiva de plantas (HU-25 / CGBIDA-461, subtarea CGBIDA-466).
 *
 * Se verifica lo que el usuario ve y lo que se manda al backend:
 *  - Las dos listas dinámicas (disciplinas y máquinas) se agregan y se quitan.
 *  - El selector de disciplina de cada máquina se alimenta de las disciplinas escritas.
 *  - La confirmación existe y resume cuántas máquinas y disciplinas se van a crear.
 *  - El payload va limpio: sin filas vacías, sin disciplinas repetidas, ubicación "" -> null.
 *  - Un 409 del backend se muestra y NO cierra el modal.
 */

const RESPUESTA: PlantaCompletaResponse = {
  planta_id: 9,
  nombre: 'Planta Norte',
  ubicacion: 'Quilicura',
  disciplinas: [
    { disciplina_id: 3, nombre: 'Mecánica', creada: true },
    { disciplina_id: 4, nombre: 'Eléctrica', creada: false },
  ],
  maquinas: [{ maquina_id: 41, nombre: 'Compressor T1', codigo: 'T1', disciplina_id: 3 }],
};

const RESPUESTA_EDITADA = { planta_id: 9, nombre: 'Planta Norte Renombrada', ubicacion: 'Maipú' };

function crearServicio(respuesta: PlantaCompletaResponse = RESPUESTA) {
  return {
    crearPlantaCompleta: vi.fn(() => of(respuesta)),
    actualizarPlanta: vi.fn(() => of(RESPUESTA_EDITADA)),
  };
}

/** Planta existente para el modo edición. */
const PLANTA_EXISTENTE: Plant = {
  id: 9,
  name: 'Planta Norte',
  ubicacion: 'Quilicura',
};

function setup(servicio = crearServicio(), planta: Plant | null = null) {
  const toast = { success: vi.fn(), error: vi.fn(), info: vi.fn(), warning: vi.fn() };
  TestBed.resetTestingModule();
  TestBed.configureTestingModule({
    imports: [PlantaFormModalComponent],
    providers: [
      { provide: CatalogService, useValue: servicio },
      { provide: ToastService, useValue: toast },
    ],
  });
  const fixture = TestBed.createComponent(PlantaFormModalComponent);
  if (planta) fixture.componentRef.setInput('planta', planta);
  fixture.detectChanges();
  return { fixture, el: fixture.nativeElement as HTMLElement, servicio, toast };
}

function escribir(el: HTMLElement, testid: string, valor: string, indice = 0): void {
  const inputs = el.querySelectorAll<HTMLInputElement>(`[data-testid="${testid}"]`);
  const input = inputs[indice];
  input.value = valor;
  input.dispatchEvent(new Event('input', { bubbles: true }));
}

function elegir(el: HTMLElement, testid: string, valor: string, indice = 0): void {
  const selects = el.querySelectorAll<HTMLSelectElement>(`[data-testid="${testid}"]`);
  selects[indice].value = valor;
  selects[indice].dispatchEvent(new Event('change', { bubbles: true }));
}

function pulsar(el: HTMLElement, testid: string, indice = 0): void {
  el.querySelectorAll<HTMLElement>(`[data-testid="${testid}"]`)[indice].click();
}

function texto(el: HTMLElement, testid: string): string {
  return el.querySelector(`[data-testid="${testid}"]`)?.textContent?.replace(/\s+/g, ' ').trim() ?? '';
}

/** Completa el mínimo para poder confirmar. */
function llenarPlanta(fixture: { detectChanges: () => void }, el: HTMLElement, nombre = 'Planta Norte') {
  escribir(el, 'planta-nombre', nombre);
  fixture.detectChanges();
}

describe('PlantaFormModalComponent', () => {
  it('abre en el paso de datos, con el nombre y la ubicación', () => {
    const { el } = setup();
    expect(el.querySelector('h2')?.textContent).toContain('Nueva planta');
    expect(el.querySelector('[data-testid="planta-nombre"]')).not.toBeNull();
    expect(el.querySelector('[data-testid="planta-ubicacion"]')).not.toBeNull();
    // Todavía no se ve la confirmación.
    expect(el.querySelector('[data-testid="confirmacion"]')).toBeNull();
  });

  describe('disciplinas', () => {
    it('empieza sin disciplinas y se pueden agregar', () => {
      const { fixture, el } = setup();
      expect(el.querySelector('[data-testid="sin-disciplinas"]')).not.toBeNull();

      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-disciplina');
      fixture.detectChanges();

      expect(el.querySelectorAll('[data-testid="disciplina-input"]')).toHaveLength(2);
      expect(el.querySelector('[data-testid="sin-disciplinas"]')).toBeNull();
    });

    it('se pueden quitar', () => {
      const { fixture, el } = setup();
      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-disciplina');
      fixture.detectChanges();

      pulsar(el, 'quitar-disciplina', 0);
      fixture.detectChanges();
      expect(el.querySelectorAll('[data-testid="disciplina-input"]')).toHaveLength(1);

      pulsar(el, 'quitar-disciplina', 0);
      fixture.detectChanges();
      expect(el.querySelector('[data-testid="sin-disciplinas"]')).not.toBeNull();
    });
  });

  describe('máquinas', () => {
    it('se agregan y se quitan, con sus tres campos', () => {
      const { fixture, el } = setup();
      expect(el.querySelector('[data-testid="sin-maquinas"]')).not.toBeNull();

      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();

      expect(el.querySelectorAll('[data-testid="maquina-nombre"]')).toHaveLength(1);
      expect(el.querySelectorAll('[data-testid="maquina-codigo"]')).toHaveLength(1);
      expect(el.querySelectorAll('[data-testid="maquina-disciplina"]')).toHaveLength(1);

      pulsar(el, 'quitar-maquina', 0);
      fixture.detectChanges();
      expect(el.querySelector('[data-testid="sin-maquinas"]')).not.toBeNull();
    });

    it('el selector ofrece las disciplinas escritas, sin repetir', () => {
      const { fixture, el } = setup();
      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();

      escribir(el, 'disciplina-input', 'Mecánica', 0);
      escribir(el, 'disciplina-input', 'mecánica', 1);
      fixture.detectChanges();

      const opciones = [...el.querySelectorAll<HTMLSelectElement>('[data-testid="maquina-disciplina"] option')]
        .map((o) => o.textContent?.trim());
      // La primera opción es "sin disciplina"; la disciplina repetida aparece una sola vez.
      expect(opciones[0]).toBe('Sin disciplina');
      expect(opciones.filter((o) => (o ?? '').toLowerCase() === 'mecánica')).toHaveLength(1);
    });

    it('una máquina a medias bloquea el avance', () => {
      const { fixture, el } = setup();
      llenarPlanta(fixture, el);
      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();

      // Con nombre pero sin código no se puede confirmar.
      escribir(el, 'maquina-nombre', 'Compressor T1');
      fixture.detectChanges();
      pulsar(el, 'continuar');
      fixture.detectChanges();

      expect(el.querySelector('[data-testid="confirmacion"]')).toBeNull();
      expect(texto(el, 'error-maquinas')).toContain('código');
    });

    it('dos máquinas con el mismo código bloquean el avance', () => {
      const { fixture, el } = setup();
      llenarPlanta(fixture, el);
      pulsar(el, 'agregar-maquina');
      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();

      escribir(el, 'maquina-nombre', 'A', 0);
      escribir(el, 'maquina-codigo', 'T1', 0);
      escribir(el, 'maquina-nombre', 'B', 1);
      escribir(el, 'maquina-codigo', 't1', 1);
      fixture.detectChanges();

      pulsar(el, 'continuar');
      fixture.detectChanges();

      expect(el.querySelector('[data-testid="confirmacion"]')).toBeNull();
      expect(texto(el, 'error-maquinas')).toContain('mismo código');
    });
  });

  describe('validación del nombre', () => {
    it('sin nombre no se avanza y se muestra el error', () => {
      const { fixture, el } = setup();
      pulsar(el, 'continuar');
      fixture.detectChanges();

      expect(el.querySelector('[data-testid="confirmacion"]')).toBeNull();
      expect(texto(el, 'error-nombre')).toContain('nombre');
    });
  });

  describe('confirmación', () => {
    it('resume cuántas máquinas y disciplinas se van a crear', () => {
      const { fixture, el } = setup();
      llenarPlanta(fixture, el);
      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-maquina');
      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();

      escribir(el, 'disciplina-input', 'Mecánica');
      escribir(el, 'maquina-nombre', 'Compressor T1', 0);
      escribir(el, 'maquina-codigo', 'T1', 0);
      escribir(el, 'maquina-nombre', 'Pump T2', 1);
      escribir(el, 'maquina-codigo', 'T2', 1);
      fixture.detectChanges();

      pulsar(el, 'continuar');
      fixture.detectChanges();

      const resumen = texto(el, 'confirmacion');
      expect(resumen).toContain('Planta Norte');
      expect(resumen).toContain('2 máquinas');
      expect(resumen).toContain('1 disciplina');
      // El botón de guardar existe en este paso.
      expect(el.querySelector('[data-testid="guardar"]')).not.toBeNull();
    });

    it('se puede volver sin perder lo escrito', () => {
      const { fixture, el } = setup();
      llenarPlanta(fixture, el, 'Planta Sur');
      pulsar(el, 'continuar');
      fixture.detectChanges();

      pulsar(el, 'volver');
      fixture.detectChanges();

      expect(el.querySelector('[data-testid="planta-nombre"]')).not.toBeNull();
      expect((el.querySelector('[data-testid="planta-nombre"]') as HTMLInputElement).value).toBe('Planta Sur');
    });
  });

  describe('envío al backend', () => {
    it('manda el SLA y el costo de inactividad de cada máquina', () => {
      const { fixture, el, servicio } = setup();
      llenarPlanta(fixture, el);

      pulsar(el, 'agregar-maquina');
      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();
      escribir(el, 'maquina-nombre', 'Compressor T1', 0);
      escribir(el, 'maquina-codigo', 'T1', 0);
      escribir(el, 'maquina-sla-horas', '8', 0);
      escribir(el, 'maquina-costo-inactividad', '3500', 0);
      escribir(el, 'maquina-nombre', 'Pump T2', 1);
      escribir(el, 'maquina-codigo', 'T2', 1);
      // La segunda queda sin SLA: debe viajar null (default de la empresa), no 0.
      fixture.detectChanges();

      pulsar(el, 'continuar');
      fixture.detectChanges();
      pulsar(el, 'guardar');
      fixture.detectChanges();

      const [payload] = (servicio.crearPlantaCompleta as any).mock.calls[0];
      expect(payload.maquinas[0].sla_horas).toBe(8);
      expect(payload.maquinas[0].costo_inactividad_minuto).toBe(3500);
      expect(payload.maquinas[1].sla_horas).toBeNull();
      expect(payload.maquinas[1].costo_inactividad_minuto).toBeNull();
    });

    it('un SLA negativo bloquea el envío y no llama al backend', () => {
      const { fixture, el, servicio } = setup();
      llenarPlanta(fixture, el);

      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();
      escribir(el, 'maquina-nombre', 'Compressor T1', 0);
      escribir(el, 'maquina-codigo', 'T1', 0);
      escribir(el, 'maquina-sla-horas', '-4', 0);
      fixture.detectChanges();

      // No avanza al paso de confirmación: el error se muestra y no hay POST.
      pulsar(el, 'continuar');
      fixture.detectChanges();

      expect(texto(el, 'error-maquinas')).toContain('SLA');
      expect(servicio.crearPlantaCompleta).not.toHaveBeenCalled();
    });

    it('manda el payload limpio: sin filas vacías, sin repetidos, ubicación null', () => {
      const { fixture, el, servicio } = setup();
      llenarPlanta(fixture, el);

      // Dos disciplinas, una repetida y una vacía.
      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-disciplina');
      pulsar(el, 'agregar-disciplina');
      fixture.detectChanges();
      escribir(el, 'disciplina-input', 'Mecánica', 0);
      escribir(el, 'disciplina-input', 'mecánica', 1);
      escribir(el, 'disciplina-input', '   ', 2);

      // Tres máquinas: dos con datos y una totalmente vacía.
      pulsar(el, 'agregar-maquina');
      pulsar(el, 'agregar-maquina');
      pulsar(el, 'agregar-maquina');
      fixture.detectChanges();
      escribir(el, 'maquina-nombre', 'Compressor T1', 0);
      escribir(el, 'maquina-codigo', 'T1', 0);
      elegir(el, 'maquina-disciplina', 'Mecánica', 0);
      escribir(el, 'maquina-nombre', 'Pump T2', 1);
      escribir(el, 'maquina-codigo', 'T2', 1);
      fixture.detectChanges();

      pulsar(el, 'continuar');
      fixture.detectChanges();
      pulsar(el, 'guardar');
      fixture.detectChanges();

      expect(servicio.crearPlantaCompleta).toHaveBeenCalledTimes(1);
      expect(servicio.crearPlantaCompleta).toHaveBeenCalledWith({
        nombre: 'Planta Norte',
        ubicacion: null,
        disciplinas: ['Mecánica'],
        maquinas: [
          {
            nombre: 'Compressor T1',
            codigo: 'T1',
            disciplina: 'Mecánica',
            sla_horas: null,
            costo_inactividad_minuto: null,
          },
          {
            nombre: 'Pump T2',
            codigo: 'T2',
            disciplina: null,
            sla_horas: null,
            costo_inactividad_minuto: null,
          },
        ],
      });
    });

    it('al crear avisa por toast y emite la respuesta', () => {
      const { fixture, el, toast } = setup();
      const emitidos: (PlantaCompletaResponse | { nombre: string })[] = [];
      fixture.componentInstance.saved.subscribe((r) => emitidos.push(r));

      llenarPlanta(fixture, el);
      pulsar(el, 'continuar');
      fixture.detectChanges();
      pulsar(el, 'guardar');
      fixture.detectChanges();

      expect(toast.success).toHaveBeenCalled();
      expect(emitidos).toHaveLength(1);
      expect((emitidos[0] as PlantaCompletaResponse).planta_id).toBe(9);
      // El mensaje distingue disciplinas nuevas de reutilizadas.
      expect(toast.success.mock.calls[0][0]).toContain('1 disciplina(s) nueva(s), 1 reutilizada(s)');
    });

    it('un 409 del backend se muestra y NO cierra el modal', () => {
      const error = new HttpErrorResponse({
        status: 409,
        error: { detail: 'Ya existe una planta llamada «Planta Norte» en tu empresa.' },
      });
      const servicio = {
        crearPlantaCompleta: vi.fn(() => throwError(() => error)),
        actualizarPlanta: vi.fn(),
      };
      const { fixture, el, toast } = setup(servicio);
      const emitidos: (PlantaCompletaResponse | { nombre: string })[] = [];
      fixture.componentInstance.saved.subscribe((r) => emitidos.push(r));

      llenarPlanta(fixture, el);
      pulsar(el, 'continuar');
      fixture.detectChanges();
      pulsar(el, 'guardar');
      fixture.detectChanges();

      expect(texto(el, 'error-servidor')).toContain('Ya existe una planta');
      expect(toast.error).toHaveBeenCalled();
      expect(emitidos).toHaveLength(0);
      // Sigue en la confirmación: el usuario puede corregir y reintentar.
      expect(el.querySelector('[data-testid="guardar"]')).not.toBeNull();
    });
  });

  it('cancelar emite closed', () => {
    const { fixture, el } = setup();
    let cerrado = false;
    fixture.componentInstance.closed.subscribe(() => (cerrado = true));

    const boton = [...el.querySelectorAll('button')].find((b) => b.textContent?.trim() === 'Cancelar')!;
    boton.click();

    expect(cerrado).toBe(true);
  });

  // --- Modo edición (HU-25, CGBIDA-466) -----------------------------------------

  describe('modo edición', () => {
    it('con una planta precarga nombre y ubicación, y cambia el título', () => {
      const { el } = setup(crearServicio(), PLANTA_EXISTENTE);
      expect(el.querySelector('h2')?.textContent).toContain('Editar planta');
      expect((el.querySelector('[data-testid="planta-nombre"]') as HTMLInputElement).value).toBe('Planta Norte');
      expect((el.querySelector('[data-testid="planta-ubicacion"]') as HTMLInputElement).value).toBe('Quilicura');
    });

    it('oculta las listas de disciplinas y máquinas', () => {
      const { el } = setup(crearServicio(), PLANTA_EXISTENTE);
      expect(el.querySelector('[data-testid="agregar-disciplina"]')).toBeNull();
      expect(el.querySelector('[data-testid="agregar-maquina"]')).toBeNull();
    });

    it('el botón dice «Guardar cambios» y no pasa por la confirmación', () => {
      const { fixture, el } = setup(crearServicio(), PLANTA_EXISTENTE);
      const boton = el.querySelector('[data-testid="continuar"]')!;
      expect(boton.textContent).toContain('Guardar cambios');

      boton.dispatchEvent(new Event('submit'));
      fixture.detectChanges();
      // Sigue en el formulario: no hay paso de confirmación en edición.
      expect(el.querySelector('[data-testid="planta-nombre"]')).not.toBeNull();
      expect(el.querySelector('[data-testid="confirmacion"]')).toBeNull();
    });

    it('guarda con PATCH y NO con el POST de alta', () => {
      const { fixture, el, servicio } = setup(crearServicio(), PLANTA_EXISTENTE);

      escribir(el, 'planta-nombre', 'Planta Norte Renombrada');
      escribir(el, 'planta-ubicacion', 'Maipú');
      fixture.detectChanges();

      el.querySelector<HTMLElement>('[data-testid="continuar"]')!.click();
      fixture.detectChanges();

      expect(servicio.actualizarPlanta).toHaveBeenCalledWith(9, {
        nombre: 'Planta Norte Renombrada',
        ubicacion: 'Maipú',
      });
      expect(servicio.crearPlantaCompleta).not.toHaveBeenCalled();
    });

    it('emite la planta actualizada y avisa por toast', () => {
      const { fixture, el, toast } = setup(crearServicio(), PLANTA_EXISTENTE);
      const emitidos: unknown[] = [];
      fixture.componentInstance.saved.subscribe((r) => emitidos.push(r));

      el.querySelector<HTMLElement>('[data-testid="continuar"]')!.click();
      fixture.detectChanges();

      expect(toast.success).toHaveBeenCalled();
      expect(emitidos).toHaveLength(1);
      expect((emitidos[0] as { nombre: string }).nombre).toBe('Planta Norte Renombrada');
    });

    it('un 409 del backend se muestra y no cierra el modal', () => {
      const error = new HttpErrorResponse({
        status: 409,
        error: { detail: 'Ya existe una planta llamada «Planta Norte Renombrada» en tu empresa.' },
      });
      const servicio = {
        crearPlantaCompleta: vi.fn(),
        actualizarPlanta: vi.fn(() => throwError(() => error)),
      };
      const { fixture, el } = setup(servicio, PLANTA_EXISTENTE);

      el.querySelector<HTMLElement>('[data-testid="continuar"]')!.click();
      fixture.detectChanges();

      // El formulario sigue visible con el mensaje del servidor.
      expect(el.querySelector('[data-testid="planta-nombre"]')).not.toBeNull();
      expect(servicio.actualizarPlanta).toHaveBeenCalled();
    });
  });
});

