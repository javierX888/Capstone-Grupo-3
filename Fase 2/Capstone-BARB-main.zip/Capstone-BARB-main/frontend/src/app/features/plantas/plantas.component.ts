import { Component, computed, inject, output, signal } from '@angular/core';
import { forkJoin, of } from 'rxjs';
import { catchError } from 'rxjs/operators';

import { Discipline, Machine, Plant } from '../../core/models';
import { CatalogService } from '../../core/services/catalog.service';
import { ToastService } from '../../core/services/toast.service';
import { apiErrorMessage } from '../../core/utils/http-error';
import { MaquinaFormModalComponent } from './maquina-form-modal.component';
import { PlantaFormModalComponent } from './planta-form-modal.component';

import { TranslatePipe } from '../../core/i18n/translate.pipe';
import { I18nService } from '../../core/i18n/i18n.service';
/** Una planta con lo que el listado necesita mostrar. */
interface PlantaFila {
  planta: Plant;
  maquinas: Machine[];
}

/**
 * Listado de plantas con el alta masiva (HU-25 / CGBIDA-461, subtarea CGBIDA-466).
 *
 * Se arma con los GET que ya existen, sin tocar el backend:
 *  - `/api/plants`     → las plantas de la empresa.
 *  - `/api/machines`   → se agrupan por `plant_id` para contar y listar sus máquinas.
 *  - `/api/disciplines`→ resuelve el nombre de la disciplina de cada máquina.
 *
 * El modal de alta es el que crea la planta con sus disciplinas y máquinas en una sola
 * transacción; al emitir `saved` este listado se recarga para reflejar lo creado.
 */
@Component({
  selector: 'app-plantas',
  imports: [PlantaFormModalComponent, MaquinaFormModalComponent, TranslatePipe],
  template: `
    <section class="flex flex-col gap-4" aria-labelledby="plantas-title">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 id="plantas-title" class="text-xl font-bold text-tinta ">
            {{ 'plantas.plantas' | translate: { v0: plantas().length } }}
          </h2>
          <p class="text-sm text-tinta-suave ">
            {{ 'plantas.plantas_de_tu_empresa' | translate }}
          </p>
        </div>
        <button type="button" class="btn-primary" data-testid="nueva-planta" (click)="openCreate()">
          {{ 'plantas.nueva_planta' | translate }}
        </button>
      </div>

      <div>
        <label for="planta-filtro" class="sr-only">{{ 'plantas.buscar_planta' | translate }}</label>
        <input
          id="planta-filtro"
          type="search"
          [attr.placeholder]="'plantas.buscar_por_nombre_o' | translate"
          class="w-full max-w-sm rounded-control border border-borde-control bg-superficie px-3 py-2 text-sm text-tinta focus:outline-none focus:ring-2 focus:ring-accion "
          [value]="filtro()"
          (input)="filtro.set($any($event.target).value)" />
      </div>

      @if (loading()) {
        <div class="py-10 text-center text-tinta-suave " role="status" data-testid="cargando">
          {{ 'plantas.cargando_plantas' | translate }}
        </div>
      } @else if (error()) {
        <div class="rounded-control border border-peligro bg-peligro-suave px-4 py-3 text-sm text-peligro" role="alert" data-testid="error">
          {{ error() }}
          <button type="button" class="ml-2 underline" (click)="load()">{{ 'plantas.reintentar' | translate }}</button>
        </div>
      } @else {
        <div class="overflow-x-auto rounded-control border border-borde bg-superficie ">
          <table class="tabla-apilada w-full text-sm text-tinta ">
            <caption class="sr-only">{{ 'plantas.listado_de_plantas' | translate }}</caption>
            <thead class="bg-superficie-2 text-sm text-tinta-suave ">
              <tr>
                <th scope="col" class="px-4 py-2 text-left">{{ 'plantas.planta' | translate }}</th>
                <th scope="col" class="px-4 py-2 text-left">{{ 'plantas.ubicacion' | translate }}</th>
                <th scope="col" class="px-4 py-2 text-right">{{ 'plantas.maquinas' | translate }}</th>
                <th scope="col" class="px-4 py-2 text-left">{{ 'plantas.disciplinas' | translate }}</th>
                <th scope="col" class="px-4 py-2 text-right">{{ 'plantas.acciones' | translate }}</th>
              </tr>
            </thead>
            <tbody>
              @for (fila of filtradas(); track fila.planta.id) {
                <tr class="border-t border-borde hover:bg-superficie-2 " data-testid="fila-planta">
                  <td class="px-4 py-2" [attr.data-label]="'plantas.planta' | translate">
                    <div class="flex items-center gap-1">
                      <button
                        type="button"
                        class="rounded-control px-1 text-tinta-suave hover:bg-superficie-2 hover:text-tinta "
                        data-testid="expandir-planta"
                        (click)="togglePlanta(fila.planta.id)"
                        [attr.aria-expanded]="expandida(fila.planta.id)"
                        [attr.aria-label]="
                          (expandida(fila.planta.id) ? 'plantas.ocultar_las_maquinas_de' : 'plantas.ver_las_maquinas_de') | translate: { v0: fila.planta.name }
                        "
                      >{{ expandida(fila.planta.id) ? '▾' : '▸' }}</button>
                      <span class="font-medium" data-testid="planta-celda-nombre">{{ fila.planta.name }}</span>
                    </div>
                    @if (fila.maquinas.length === 0) {
                      <div class="text-sm text-tinta-suave ">{{ 'plantas.sin_maquinas' | translate }}</div>
                    }
                  </td>
                  <td class="px-4 py-2" [attr.data-label]="'plantas.ubicacion' | translate" data-testid="planta-celda-ubicacion">{{ fila.planta.ubicacion || '—' }}</td>
                  <td class="px-4 py-2 text-right font-medium" [attr.data-label]="'plantas.maquinas' | translate" data-testid="planta-celda-maquinas">
                    {{ fila.maquinas.length }}
                  </td>
                  <td class="px-4 py-2" [attr.data-label]="'plantas.disciplinas' | translate">
                    @if (disciplinasDe(fila).length) {
                      <div class="flex flex-wrap gap-1">
                        @for (d of disciplinasDe(fila); track d) {
                          <span class="rounded-control bg-superficie-2 px-2 py-0.5 text-sm text-tinta ">{{ d }}</span>
                        }
                      </div>
                    } @else {
                      <span class="text-tinta-suave">—</span>
                    }
                  </td>
                  <td class="px-4 py-2" [attr.data-label]="'plantas.acciones' | translate">
                    <div class="flex justify-end gap-1">
                      <button
                        type="button"
                        class="btn-secondary"
                        data-testid="editar-planta"
                        (click)="openEdit(fila.planta)"
                        [attr.aria-label]="'plantas.editar_2' | translate: { v0: fila.planta.name }"
                      >{{ 'plantas.editar' | translate }}</button>
                      <button
                        type="button"
                        class="btn-secondary"
                        data-testid="agregar-maquina"
                        (click)="openMaquina(fila.planta)"
                        [attr.aria-label]="'plantas.agregar_maquina_a' | translate: { v0: fila.planta.name }"
                      >{{ 'plantas.maquina' | translate }}</button>
                    </div>
                  </td>
                </tr>

                @if (expandida(fila.planta.id)) {
                  <tr class="bg-superficie-2 " data-testid="fila-maquinas">
                    <td colspan="5" class="px-4 py-3">
                      @if (fila.maquinas.length === 0) {
                        <p class="text-sm text-tinta-suave " data-testid="sin-maquinas-planta">
                          {{ 'plantas.esta_planta_no_tiene' | translate }}
                        </p>
                      } @else {
                        <table class="w-full text-sm">
                          <caption class="sr-only">{{ 'plantas.maquinas_de' | translate: { v0: fila.planta.name } }}</caption>
                          <thead class="text-sm text-tinta-suave ">
                            <tr>
                              <th scope="col" class="py-1 pr-3 text-left">{{ 'plantas.maquina_2' | translate }}</th>
                              <th scope="col" class="py-1 pr-3 text-left">{{ 'plantas.codigo' | translate }}</th>
                              <th scope="col" class="py-1 pr-3 text-left">{{ 'plantas.disciplina' | translate }}</th>
                              <th scope="col" class="py-1 pr-3 text-right">SLA</th>
                              <th scope="col" class="py-1 pr-3 text-right">{{ 'plantas.costo_inactividad_min' | translate }}</th>
                              <th scope="col" class="py-1 text-right">{{ 'plantas.acciones' | translate }}</th>
                            </tr>
                          </thead>
                          <tbody>
                            @for (maquina of fila.maquinas; track maquina.id) {
                              <tr class="border-t border-borde " data-testid="fila-maquina">
                                <td class="py-1 pr-3" data-testid="maquina-nombre">{{ maquina.name }}</td>
                                <td class="py-1 pr-3" data-testid="maquina-codigo">{{ maquina.codigo || '—' }}</td>
                                <td class="py-1 pr-3" data-testid="maquina-disciplina">
                                  {{ nombreDisciplina(maquina) }}
                                </td>
                                <td class="py-1 pr-3 text-right" data-testid="maquina-sla">{{ slaDe(maquina) }}</td>
                                <td class="py-1 pr-3 text-right" data-testid="maquina-costo">{{ costoDe(maquina) }}</td>
                                <td class="py-1 text-right">
                                  <button
                                    type="button"
                                    class="btn-secondary"
                                    data-testid="editar-maquina"
                                    (click)="openEditarMaquina(fila.planta, maquina)"
                                    [attr.aria-label]="'plantas.editar_2' | translate: { v0: maquina.name }"
                                  >{{ 'plantas.editar' | translate }}</button>
                                </td>
                              </tr>
                            }
                          </tbody>
                        </table>
                      }
                    </td>
                  </tr>
                }
              } @empty {
                <tr>
                  <td colspan="5" class="py-6 text-center text-tinta-suave " data-testid="vacio">
                    {{ 'plantas.no_hay_plantas_todavia' | translate }}
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      }
    </section>

    @if (modalOpen()) {
      <app-planta-form-modal [planta]="editing()" (closed)="closeModal()" (saved)="onSaved()" />
    }

    @if (maquinaPara(); as planta) {
      <app-maquina-form-modal
        [planta]="planta"
        [disciplinas]="listaDisciplinas()"
        [maquina]="maquinaEditando()"
        (closed)="closeMaquina()"
        (saved)="onMaquinaSaved()"
      />
    }
  `,
})
export class PlantasComponent {
  private readonly i18n = inject(I18nService);
  private readonly catalogo = inject(CatalogService);
  private readonly toast = inject(ToastService);

  protected readonly plantas = signal<PlantaFila[]>([]);
  protected readonly disciplinas = signal<Map<number, string>>(new Map());
  /** Lista completa, para el datalist del modal de máquina. */
  protected readonly listaDisciplinas = signal<Discipline[]>([]);
  protected readonly loading = signal(true);
  protected readonly error = signal<string | null>(null);
  protected readonly filtro = signal('');
  protected readonly modalOpen = signal(false);
  /** Planta en edición; null = alta. */
  protected readonly editing = signal<Plant | null>(null);
  /** Planta a la que se le agrega una máquina; null = modal cerrado. */
  protected readonly maquinaPara = signal<Plant | null>(null);
  /** Máquina en edición; null = el modal está en modo alta. */
  protected readonly maquinaEditando = signal<Machine | null>(null);

  /**
   * Plantas expandidas. Se guarda el id (no el índice) para que la expansión sobreviva a un
   * `load()`: después de editar una máquina la tabla se recarga y el usuario no debería
   * perder la fila que estaba mirando.
   */
  protected readonly expandidas = signal<ReadonlySet<number>>(new Set());

  protected expandida(plantaId: number): boolean {
    return this.expandidas().has(plantaId);
  }

  protected togglePlanta(plantaId: number): void {
    this.expandidas.update((actual) => {
      const siguiente = new Set(actual);
      if (siguiente.has(plantaId)) {
        siguiente.delete(plantaId);
      } else {
        siguiente.add(plantaId);
      }
      return siguiente;
    });
  }

  /** Nombre de la disciplina de una máquina, o «—». */
  protected nombreDisciplina(maquina: Machine): string {
    if (!maquina.discipline_id) return '—';
    return this.disciplinas().get(maquina.discipline_id) ?? '—';
  }

  /** SLA de la máquina; si es null hereda el de la empresa, y se dice explícitamente. */
  protected slaDe(maquina: Machine): string {
    return maquina.sla_horas != null ? `${maquina.sla_horas} h` : this.i18n.tr('plantas.gral');
  }

  /** Costo de inactividad por minuto; sin dato por equipo se muestra «— (gral)». */
  protected costoDe(maquina: Machine): string {
    const valor = maquina.costo_inactividad_minuto;
    return valor != null ? valor.toLocaleString('es-CL') : this.i18n.tr('plantas.gral');
  }

  /**
   * Avisa que el catálogo cambió (alta o edición de planta, alta de máquina).
   *
   * Topología lo escucha para volver a pedir el mapa: la tabla y el mapa son la misma
   * pantalla, y sin esto el mapa seguiría mostrando los activos de antes del cambio.
   */
  readonly actualizado = output<void>();

  protected readonly filtradas = computed(() => {
    const q = this.filtro().trim().toLowerCase();
    if (!q) return this.plantas();
    return this.plantas().filter((f) =>
      [f.planta.name, f.planta.ubicacion].some((v) => (v ?? '').toLowerCase().includes(q)),
    );
  });

  constructor() {
    this.load();
  }

  /**
   * Carga plantas y máquinas en paralelo.
   *
   * Si fallan las máquinas, el listado igual se muestra con 0: es preferible ver las
   * plantas sin contadores que una pantalla de error por un dato accesorio.
   */
  protected load(): void {
    this.loading.set(true);
    this.error.set(null);
    forkJoin({
      plantas: this.catalogo.getPlants(),
      maquinas: this.catalogo.getMachines().pipe(catchError(() => of([] as Machine[]))),
      disciplinas: this.catalogo.getDisciplines().pipe(catchError(() => of([]))),
    }).subscribe({
      next: ({ plantas, maquinas, disciplinas }) => {
        this.disciplinas.set(new Map(disciplinas.map((d) => [d.id, d.name])));
        this.listaDisciplinas.set(disciplinas);
        this.plantas.set(
          plantas.map((planta) => ({
            planta,
            maquinas: maquinas.filter((m) => m.plant_id === planta.id),
          })),
        );
        this.loading.set(false);
      },
      error: (err) => {
        this.error.set(apiErrorMessage(err, this.i18n.tr('plantas.no_se_pudieron_cargar')));
        this.loading.set(false);
      },
    });
  }

  /** Nombres de disciplina distintos que usan las máquinas de una planta. */
  protected disciplinasDe(fila: PlantaFila): string[] {
    const nombres = new Set<string>();
    for (const maquina of fila.maquinas) {
      const nombre = maquina.discipline_id ? this.disciplinas().get(maquina.discipline_id) : undefined;
      if (nombre) nombres.add(nombre);
    }
    return [...nombres].sort((a, b) => a.localeCompare(b));
  }

  protected openCreate(): void {
    this.editing.set(null);
    this.modalOpen.set(true);
  }

  protected openEdit(planta: Plant): void {
    this.editing.set(planta);
    this.modalOpen.set(true);
  }

  protected openMaquina(planta: Plant): void {
    this.maquinaEditando.set(null);
    this.maquinaPara.set(planta);
  }

  /** Abre el modal en modo edición con la máquina elegida (y su planta, para el título). */
  protected openEditarMaquina(planta: Plant, maquina: Machine): void {
    this.maquinaPara.set(planta);
    this.maquinaEditando.set(maquina);
    // Al editar conviene ver la planta expandida al volver.
    this.expandidas.update((actual) => new Set(actual).add(planta.id));
  }

  protected closeMaquina(): void {
    this.maquinaPara.set(null);
    this.maquinaEditando.set(null);
  }

  protected onMaquinaSaved(): void {
    this.maquinaPara.set(null);
    this.maquinaEditando.set(null);
    this.load();
    this.actualizado.emit();
  }

  protected closeModal(): void {
    this.modalOpen.set(false);
  }

  protected onSaved(): void {
    this.modalOpen.set(false);
    this.toast.info('Listado actualizado.');
    this.load();
    this.actualizado.emit();
  }
}




