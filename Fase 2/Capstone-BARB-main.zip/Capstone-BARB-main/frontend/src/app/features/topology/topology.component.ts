import { Component, computed, effect, inject, signal } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { Subject, catchError, map, merge, of, switchMap } from 'rxjs';

import {
  Topology,
  TopologyConnection,
  TopologyNode,
  TopologyNodeState,
  TopologyNodoDetalle,
  WorkOrder,
  WorkOrderStatus,
} from '../../core/models';
import { I18nService } from '../../core/i18n/i18n.service';
import { TopologyService } from '../../core/services/topology.service';
import { OtDetailSheetComponent } from '../work-orders/components/ot-detail-sheet/ot-detail-sheet.component';
import { PlantasComponent } from '../plantas/plantas.component';
import { textoActual } from '../../core/i18n/i18n.service';
import { PermissionsService } from '../../core/permissions/permissions.service';
import { filterGroup } from '../work-orders/utils/work-order-labels';

import { TranslatePipe } from '../../core/i18n/translate.pipe';
/** Dimensiones de la tarjeta de cada nodo, en unidades del viewBox. */
const NODE_W = 130;
const NODE_H = 85;

/**
 * Ancho útil para el nombre dentro de la tarjeta: el ancho del nodo menos 8 unidades de
 * aire a cada lado. Es el límite que `textLength` impone a los nombres largos.
 */
const ANCHO_NOMBRE_NODO = NODE_W - 16;

/** Desplazamiento (px) desde el que un toque deja de ser un «toque» y pasa a ser un arrastre. */
const UMBRAL_TOQUE_PX = 8;

/** Factor de zoom por paso de rueda. 1,15 se siente continuo sin saltar de golpe. */
const FACTOR_RUEDA = 1.15;

/**
 * Aire entre el borde de la tarjeta y la punta de flecha.
 *
 * Sin él la flecha se apoya en el borde y se confunde con el trazo del rectángulo.
 */
const AIRE_FLECHA = 4;

/**
 * Aire alrededor del grafo, en unidades del viewBox.
 *
 * Sin este margen el nodo de la izquierda queda pegado al borde del lienzo y el de la
 * derecha también, así que el mapa se ve recortado aunque esté completo.
 */
const PADDING_VISTA = 80;

/**
 * Vista de respaldo cuando todavía no hay nodos (CGBIDA-362).
 *
 * Con datos, la cámara arranca en el rectángulo que contiene el grafo (`cajaContenido`).
 * La vista fija anterior era 1200x800 en (-100,-50), y el mapa real llega a x=2160: diez
 * de los veintiún nodos quedaban fuera de cuadro al cargar.
 */
const INITIAL_VIEW = { x: -100, y: -50, w: 1200, h: 800 };

/**
 * Estado de carga como unión discriminada: evita ambigüedad entre "aún cargando",
 * "falló" y "respondió vacío", que el usuario debe poder distinguir.
 */
type EstadoCarga =
  | { tipo: 'cargando' }
  | { tipo: 'error' }
  | { tipo: 'vacio' }
  | { tipo: 'listo'; topologia: Topology };

/**
 * Color por estado. Tailwind en Tailwind v4 se resuelve a `var(--color-*)`, así que
 * se puede enlazar directo en un atributo SVG (a diferencia de las clases del legacy).
 */
const COLOR_POR_ESTADO: Record<TopologyNodeState, string> = {
  operativo: 'var(--ok)',
  alerta: 'var(--media)',
  falla: 'var(--peligro)',
  desconectado: 'var(--neutro)',
};

/** Clave de traducción de cada estado. El texto vive en `translations.topology`. */
const CLAVE_ESTADO: Record<TopologyNodeState, string> = {
  operativo: 'stateOperativo',
  alerta: 'stateAlerta',
  falla: 'stateFalla',
  desconectado: 'stateDesconectado',
};

// --- HU-377 · CGBIDA-383: agrupación de los 6 estados de OT -------------------
//
// La agrupación NO se decide aquí: se reutiliza `filterGroup()`
// (`features/work-orders/utils/work-order-labels.ts`), que ya unifica `assigned` y
// `overdue` bajo `pending`. El backend aplica la misma regla en
// `core/work_order_states.py` (los tres estados comparten transiciones).
// Duplicarla aquí haría que el panel de topología y el listado de OTs discreparan.
//
// `overdue` se agrupa con Pendientes por ciclo de vida, pero se marca con un badge
// rojo (decisión de CGBIDA-378) para que el supervisor lo distinga sin cambiar de grupo.

type GrupoOt = 'groupPendientes' | 'groupEnCurso' | 'groupCerradas' | 'groupCanceladas';

/** Orden dentro de cada grupo: por número de OT (A-Z) o por fecha de creación. */
type OrdenOt = 'az' | 'recientes';

/** Orden de presentación de los grupos; el usuario ve primero lo que exige acción. */
const ORDEN_GRUPOS: GrupoOt[] = ['groupPendientes', 'groupEnCurso', 'groupCerradas', 'groupCanceladas'];

/**
 * Estado ya normalizado por `filterGroup()` -> grupo del panel.
 * Las claves son los 4 estados que devuelve `filterGroup`, no los 6 del backend.
 */
const CLAVE_GRUPO: Record<string, GrupoOt> = {
  pending: 'groupPendientes',
  in_progress: 'groupEnCurso',
  // Por validar sigue siendo trabajo abierto: se agrupa con «En curso».
  por_validar: 'groupEnCurso',
  completed: 'groupCerradas',
  cancelled: 'groupCanceladas',
};

/** Etiqueta por estado, para el badge de cada tarjeta. */
// Con `get`: el texto se calcula al leerlo y sigue el idioma elegido.
const ETIQUETA_OT: Record<string, string> = {
  get pending() { return textoActual('ot.pendiente'); },
  get assigned() { return textoActual('ot.asignada'); },
  get in_progress() { return textoActual('ot.en_curso'); },
  get por_validar() { return textoActual('ot.por_validar'); },
  get overdue() { return textoActual('ot.vencida'); },
  get completed() { return textoActual('ot.cerrada'); },
  get cancelled() { return textoActual('ot.cancelada'); },
};

/** Color del badge por estado, coherente con `work-order-labels.ts`. */
const COLOR_OT: Record<string, string> = {
  pending: 'bg-media-suave text-media',
  assigned: 'bg-accion-suave text-accion',
  in_progress: 'bg-accion-suave text-accion',
  por_validar: 'bg-alerta-suave text-alerta',
  overdue: 'bg-peligro-suave text-peligro',
  completed: 'bg-ok-suave text-ok',
  cancelled: 'bg-borde text-tinta',
};

interface OtEnPanel {
  orden: WorkOrder;
  /** `overdue` lleva badge rojo dentro de su grupo (CGBIDA-378). */
  vencida: boolean;
  etiqueta: string;
  color: string;
}

interface GrupoEnPanel {
  nombre: GrupoOt;
  ordenes: OtEnPanel[];
}

@Component({
  selector: 'app-topology',
  standalone: true,
  imports: [OtDetailSheetComponent, PlantasComponent, TranslatePipe],
  // El hover de las aristas no se puede expresar con atributos: cambiar el grosor, el
  // color y la punta de flecha a la vez pide CSS.
  styles: `
    /*
     * Aristas (HU-25, mejora visual): curvas en vez de rectas.
     *
     * Con líneas rectas el grafo se leía como una telaraña: todas las aristas de una planta
     * salían en abanico y se cruzaban con las de la otra. La curva Bézier vertical mantiene
     * cada arista en su "carril" entre niveles, así que los cruces dejan de ser una X.
     */
    .arista {
      marker-end: url(#flecha-topo);
      stroke-width: 1.5;
      opacity: 0.8;
      transition: stroke 120ms ease, stroke-width 120ms ease, opacity 160ms ease;
    }

    .arista:hover {
      stroke-width: 2.5;
      opacity: 1;
      stroke: var(--color-blue-600);
      marker-end: url(#flecha-topo-activa);
    }

    /* Al pasar el mouse por un nodo: su rama se enciende y el resto se apaga. */
    .arista-foco {
      stroke-width: 2.25;
      opacity: 1;
      stroke: var(--color-blue-600);
      marker-end: url(#flecha-topo-activa);
    }

    .arista-ajena {
      opacity: 0.1;
    }

    .topo-node {
      cursor: pointer;
      transition: opacity 160ms ease;
    }

    .nodo-ajeno {
      opacity: 0.3;
    }
  `,
  template: `
    <div class="flex flex-col gap-4">
      <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 class="text-2xl font-bold text-tinta ">{{ t().title }}</h1>
          <p class="text-sm text-tinta-suave " data-testid="topo-subtitulo">{{ vistaActivos() ? t().subtitleAssets : t().subtitle }}</p>
        </div>
        <div class="flex flex-wrap gap-2">
          <!--
            El mantenedor de plantas vive acá y no en el menú lateral: se entra desde el
            mapa, que es donde tiene sentido (los activos que se están mirando). Solo lo ve
            gerente/admin, el mismo permiso que exige el backend para la ruta plantas.
          -->
          @if (puedeGestionar()) {
            <button
              type="button"
              data-testid="gestionar-activos"
              data-tour="topo-gestionar"
              (click)="alternarVista()"
              class="inline-flex min-h-11 items-center justify-center rounded-control border border-borde-control bg-superficie px-3 text-sm hover:bg-superficie-2"
            >{{ (vistaActivos() ? 'sistema.volver_al_mapa' : 'sistema.gestionar_activos') | translate }}</button>
          }
          <!-- Los controles de cámara solo tienen sentido sobre el mapa. -->
          @if (!vistaActivos()) {
            <button
              type="button"
              data-testid="zoom-in"
              (click)="zoom(1.2)"
              class="inline-flex min-h-11 min-w-11 items-center justify-center rounded-control border border-borde-control bg-superficie px-3 text-lg hover:bg-superficie-2"
              [attr.aria-label]="t().zoomIn"
            >+</button>
            <button
              type="button"
              data-testid="zoom-out"
              (click)="zoom(0.8)"
              class="inline-flex min-h-11 min-w-11 items-center justify-center rounded-control border border-borde-control bg-superficie px-3 text-lg hover:bg-superficie-2"
              [attr.aria-label]="t().zoomOut"
            >−</button>
            <button
              type="button"
              data-testid="zoom-reset"
              (click)="resetView()"
              class="inline-flex min-h-11 items-center justify-center rounded-control border border-borde-control bg-superficie px-3 text-sm hover:bg-superficie-2"
            >{{ t().resetView }}</button>
          }
        </div>
      </div>

      @if (!vistaActivos()) {
      <!-- Leyenda de estados -->
      <div class="flex flex-wrap gap-4 text-sm text-tinta-suave ">
        @for (e of estados; track e) {
          <span class="inline-flex items-center gap-2">
            <span
              class="inline-block w-3 h-3 rounded-full"
              [style.background-color]="colorDe(e)"
            ></span>
            {{ etiquetaDe(e) }}
          </span>
        }
      </div>

      <div class="relative bg-superficie rounded-control border border-borde overflow-hidden ">
        @switch (estado()) {
          @case ('cargando') {
            <div class="p-10 text-center text-tinta-suave " data-testid="estado-cargando">
              {{ t().loading }}
            </div>
          }
          @case ('error') {
            <div class="p-10 text-center text-peligro " data-testid="estado-error" role="alert">
              {{ t().loadError }}
            </div>
          }
          @case ('vacio') {
            <div class="p-10 text-center text-tinta-suave " data-testid="estado-vacio">
              {{ t().empty }}
            </div>
          }
          @default {
            <svg
              data-testid="topo-canvas"
              [attr.viewBox]="viewBoxAttr()"
              preserveAspectRatio="xMidYMid meet"
              class="h-[min(560px,62dvh)] w-full select-none md:h-[560px]"
              [class.cursor-grabbing]="arrastrando()"
              [class.cursor-grab]="!arrastrando()"
              style="touch-action: none"
              (mousedown)="onMouseDown($event)"
              (mousemove)="onMouseMove($event)"
              (mouseup)="onMouseUp()"
              (mouseleave)="onMouseUp()"
              (pointerdown)="onPointerDown($event)"
              (pointermove)="onPointerMove($event)"
              (pointerup)="onPointerEnd($event)"
              (pointercancel)="onPointerEnd($event)"
              (wheel)="onWheel($event)"
            >
              <!--
                Dos puntas de flecha: la normal y la del hover. El color va en clases para
                que siga al tema; si se cambiara sólo el trazo, la flecha quedaría gris.
              -->
              <defs>
                <marker
                  id="flecha-topo"
                  viewBox="0 0 8 8"
                  refX="7"
                  refY="4"
                  markerWidth="9"
                  markerHeight="9"
                  markerUnits="userSpaceOnUse"
                  orient="auto"
                >
                  <path d="M0,0 L8,4 L0,8 z" class="fill-borde-control " />
                </marker>
                <marker
                  id="flecha-topo-activa"
                  viewBox="0 0 8 8"
                  refX="7"
                  refY="4"
                  markerWidth="11"
                  markerHeight="11"
                  markerUnits="userSpaceOnUse"
                  orient="auto"
                >
                  <path d="M0,0 L8,4 L0,8 z" class="fill-accion " />
                </marker>
              </defs>

              <!-- Conexiones: curvas Bézier con enfoque por nodo -->
              <g class="stroke-borde-control " fill="none">
                @for (e of aristas(); track e.conexion_id) {
                  <path
                    class="arista"
                    [class.arista-foco]="leToca(e)"
                    [class.arista-ajena]="hayFoco() && !leToca(e)"
                    [attr.d]="e.d"
                    [attr.data-relacion]="e.tipo_relacion"
                  />
                }
              </g>

              <!-- Nodos -->
              @for (n of nodos(); track n.nodo_id) {
                <g
                  class="topo-node"
                  [class.nodo-ajeno]="hayFoco() && !nodoEnFoco(n)"
                  [attr.transform]="'translate(' + n.pos_x + ',' + n.pos_y + ')'"
                  [attr.data-nodo-id]="n.nodo_id"
                  [attr.data-tipo]="n.tipo"
                  [attr.data-estado]="n.estado_actual"
                  (click)="seleccionar(n, $event)"
                  (mouseenter)="resaltado.set(n.nodo_id)"
                  (mouseleave)="resaltado.set(null)"
                >
                  <rect
                    x="0"
                    y="0"
                    [attr.width]="nodeW"
                    [attr.height]="nodeH"
                    rx="12"
                    class="fill-superficie "
                    [attr.stroke]="colorDe(n.estado_actual)"
                    stroke-width="2"
                  />
                  <text x="65" y="28" text-anchor="middle" font-size="22">{{ n.icono }}</text>
                  <text
                    x="65"
                    y="50"
                    text-anchor="middle"
                    font-size="11"
                    font-weight="600"
                    class="topo-node-name fill-tinta "
                    [attr.textLength]="anchoNombre(n.nombre_visual)"
                    lengthAdjust="spacingAndGlyphs"
                  >{{ n.nombre_visual }}</text>
                  <text
                    x="65"
                    y="65"
                    text-anchor="middle"
                    font-size="10"
                    class="topo-node-type fill-tinta-suave "
                  >{{ n.tipo }}</text>
                  <circle
                    [attr.cx]="nodeW - 14"
                    cy="14"
                    r="7"
                    [attr.fill]="colorDe(n.estado_actual)"
                  />
                </g>
              }
            </svg>

            <!-- Panel de detalle del equipo seleccionado (CGBIDA-364) -->
            @if (seleccionado(); as n) {
              <div
                data-testid="panel-detalle"
                class="absolute top-3 right-3 w-72 max-h-[90%] overflow-y-auto rounded-control border border-borde bg-superficie p-4 shadow-lg "
              >
                <div class="flex items-start justify-between gap-2">
                  <div class="min-w-0">
                    <p class="font-semibold text-tinta truncate " data-testid="panel-nombre">
                      {{ n.nombre_visual }}
                    </p>
                    <p class="text-sm text-tinta-suave " data-testid="panel-tipo">{{ n.tipo }}</p>
                  </div>
                  <span class="text-xl" aria-hidden="true">{{ n.icono }}</span>
                </div>

                <div class="mt-3 flex items-center gap-2" data-testid="panel-estado">
                  <span
                    class="inline-block w-3 h-3 rounded-full"
                    [style.background-color]="colorDe(n.estado_actual)"
                  ></span>
                  <span class="text-sm text-tinta ">{{ etiquetaDe(n.estado_actual) }}</span>
                </div>

                @if (esBotonVolver()) {
                  <button
                    type="button"
                    data-testid="panel-volver"
                    (click)="volver()"
                    class="mt-3 text-sm text-accion underline hover:text-accion "
                  >&larr; {{ t().detailBack }}</button>
                }

                <!-- CGBIDA-383: órdenes de trabajo, solo en nodos Máquina -->
                @if (n.tipo === 'Máquina') {
                  <div class="mt-3 border-t border-borde pt-2 ">
                    <p class="text-sm font-semibold text-tinta-suave ">
                      {{ t().ordersTitle }}
                    </p>

                    @switch (estadoDetalle()) {
                      @case ('cargando') {
                        <p class="mt-2 text-sm text-tinta-suave " data-testid="ordenes-cargando">
                          {{ t().ordersLoading }}
                        </p>
                      }
                      @case ('error') {
                        <p class="mt-2 text-sm text-peligro " data-testid="ordenes-error">
                          {{ t().ordersError }}
                        </p>
                      }
                      @default {
                        @if (gruposDeOrdenes().length) {
                          <!--
                            Fila de controles. 40 px de alto y una sola línea: el panel mide
                            288 px (256 internos) y el listado ya scrollea, así que el costo
                            vertical es despreciable y el horizontal entra con holgura.
                          -->
                          <div class="mt-1.5 flex items-center gap-1.5" data-testid="ordenes-controles">
                            <select
                              class="min-w-0 flex-1 rounded-control border border-borde-control bg-superficie px-1.5 py-1 text-sm
                                     text-tinta "
                              [value]="filtroEstado()"
                              (change)="cambiarFiltro($any($event.target).value)"
                              data-testid="filtro-estado"
                            >
                              <option value="todos">{{ t().filterAll }} ({{ totalOrdenes() }})</option>
                              @for (opcion of gruposDeOrdenes(); track opcion.nombre) {
                                <option [value]="opcion.nombre">
                                  {{ t()[opcion.nombre] }} ({{ opcion.ordenes.length }})
                                </option>
                              }
                            </select>
                            <button
                              type="button"
                              (click)="alternarOrden()"
                              class="shrink-0 rounded-control border border-borde-control bg-superficie px-1.5 py-1 text-sm
                                     text-tinta hover:bg-superficie-2  
                                      "
                              [attr.aria-label]="t().sortAz + ' / ' + t().sortRecent"
                              [attr.title]="etiquetaOrden()"
                              data-testid="orden-ot"
                            >
                              <span aria-hidden="true">⇅</span> {{ etiquetaOrden() }}
                            </button>
                          </div>

                          @for (grupo of gruposVisibles(); track grupo.nombre) {
                            <!--
                              La cabecera es un botón: pliega el grupo. El chevron rota 90°
                              cuando está abierto y aria-expanded lo anuncia.
                            -->
                            <button
                              type="button"
                              class="sticky top-0 z-10 -mx-1 mt-1 flex w-full cursor-pointer items-center gap-1
                                     bg-superficie px-1 py-0.5 text-left text-sm font-medium text-tinta
                                     hover:text-tinta "
                              [attr.data-testid]="'grupo-' + grupo.nombre"
                              [attr.aria-expanded]="!estaPlegado(grupo.nombre)"
                              (click)="alternarGrupo(grupo.nombre)"
                            >
                              <span
                                class="inline-block w-3 shrink-0 transition-transform"
                                [class.rotate-90]="!estaPlegado(grupo.nombre)"
                                aria-hidden="true"
                              >▸</span>
                              {{ t()[grupo.nombre] }} ({{ grupo.ordenes.length }})
                            </button>

                            @if (!estaPlegado(grupo.nombre)) {
                              <ul class="mt-0.5 flex flex-col gap-1" data-testid="grupo-lista">
                                @for (item of grupo.ordenes; track item.orden.numero_ot) {
                                  <li
                                    class="rounded-control border border-borde px-2 py-1 "
                                    data-testid="orden-item"
                                  >
                                    <div class="flex items-center gap-1">
                                      <span
                                        class="truncate text-sm font-medium text-tinta "
                                        data-testid="orden-numero"
                                      >{{ item.orden.numero_ot }}</span>
                                      <span
                                        class="ml-auto shrink-0 rounded-control px-1 text-sm"
                                        [class]="item.color"
                                        data-testid="orden-estado"
                                      >{{ item.etiqueta }}</span>
                                    </div>
                                    <!-- Badge rojo de vencida (CGBIDA-378) -->
                                    @if (item.vencida) {
                                      <span
                                        class="mt-1 inline-block rounded-control bg-peligro px-1 text-sm font-semibold text-sobre-accion"
                                        data-testid="orden-vencida"
                                      >{{ t().overdueBadge }}</span>
                                    }
                                    <button
                                      type="button"
                                      data-testid="orden-ver-detalle"
                                      (click)="abrirDetalleOt(item.orden)"
                                      class="mt-1 block text-sm text-accion underline hover:text-accion "
                                    >{{ t().viewOrderDetail }}</button>
                                  </li>
                                }
                              </ul>
                            }
                          }
                        } @else {
                          <p class="mt-2 text-sm text-tinta-suave " data-testid="ordenes-vacio">
                            {{ t().ordersEmpty }}
                          </p>
                        }
                      }
                    }
                  </div>
                }

                <!-- CGBIDA-384: hijos del nodo, para Planta y Disciplina -->
                @if (n.tipo !== 'Máquina') {
                  <div class="mt-3 border-t border-borde pt-2 ">
                    <p class="text-sm font-semibold text-tinta-suave ">
                      {{ t().childrenTitle }}
                    </p>

                    @switch (estadoDetalle()) {
                      @case ('cargando') {
                        <p class="mt-2 text-sm text-tinta-suave " data-testid="hijos-cargando">
                          {{ t().childrenLoading }}
                        </p>
                      }
                      @case ('error') {
                        <p class="mt-2 text-sm text-peligro " data-testid="hijos-error">
                          {{ t().childrenError }}
                        </p>
                      }
                      @default {
                        @if (hijos().length) {
                          <ul class="mt-2 flex flex-col gap-1">
                            @for (hijo of hijos(); track hijo.nodo_id) {
                              <li>
                                <button
                                  type="button"
                                  data-testid="hijo-item"
                                  [attr.data-nodo-id]="hijo.nodo_id"
                                  (click)="seleccionarHijo(hijo)"
                                  class="flex w-full items-center gap-2 rounded-control border border-borde px-2 py-1 text-left hover:bg-superficie-2 "
                                >
                                  <span
                                    class="inline-block w-2 h-2 shrink-0 rounded-full"
                                    [style.background-color]="colorDe(hijo.estado_actual)"
                                  ></span>
                                  <span class="truncate text-sm text-tinta ">{{ hijo.nombre_visual }}</span>
                                  <span class="ml-auto shrink-0 text-sm text-tinta-suave ">{{ hijo.tipo }}</span>
                                </button>
                              </li>
                            }
                          </ul>
                        } @else {
                          <p class="mt-2 text-sm text-tinta-suave " data-testid="hijos-vacio">
                            {{ t().childrenEmpty }}
                          </p>
                        }
                      }
                    }
                  </div>
                }

                <button
                  type="button"
                  data-testid="panel-cerrar"
                  (click)="cerrarPanel()"
                  class="mt-4 w-full rounded-control border border-borde-control px-3 py-2 text-sm hover:bg-superficie-2 "
                >{{ t().closePanel }}</button>
              </div>
            }

            <!-- CGBIDA-385: el detalle de una OT es un sheet, no una ruta.
                 Se reutiliza el componente que ya usa el listado de OTs. -->
            @if (otEnDetalle(); as ot) {
              <app-ot-detail-sheet
                [order]="ot"
                (closed)="cerrarDetalleOt()"
                (changeRequested)="cerrarDetalleOt()"
              />
            }
          }
        }
      </div>
      } @else {
        <!-- Mantenedor de plantas dentro de Topología (HU-25, CGBIDA-466).
             El mapa se desmonta, pero su cámara (viewBox) vive en signals del
             componente, así que al volver se conserva el zoom y el paneo. -->
        <app-plantas (actualizado)="recargarTopologia()" />
      }
    </div>
  `,
})
export class TopologyComponent {
  private readonly topologyService = inject(TopologyService);
  private readonly i18n = inject(I18nService);
  private readonly permisos = inject(PermissionsService);

  /** Textos de la pantalla. Es un computed, así que cambia al alternar el idioma. */
  protected readonly t = computed(() => this.i18n.tree().topology);

  /**
   * El mantenedor de plantas se abre desde acá (HU-25, CGBIDA-466), no desde el menú.
   *
   * Mismo permiso que exige el backend para la ruta `plantas`: sólo gerente y admin. El
   * `role()` de dentro del computed hace que se recalcule al iniciar o cerrar sesión.
   */
  protected readonly puedeGestionar = computed(() => {
    this.permisos.role();
    return this.permisos.canAccess('plantas');
  });

  /** Mapa o tabla de activos. El mapa se desmonta, pero su cámara no se pierde. */
  protected readonly vistaActivos = signal(false);

  protected alternarVista(): void {
    if (this.vistaActivos()) {
      // Al cerrar el mantenedor se sale del panel de detalle: si no, al volver al mapa
      // aparecería el panel de un nodo que el usuario ya no recuerda haber abierto.
      this.seleccionado.set(null);
      // Y se refresca el mapa: el usuario pudo haber creado o editado activos.
      this.recargarTopologia();
    }
    this.vistaActivos.update((v) => !v);
  }

  protected readonly nodeW = NODE_W;
  protected readonly nodeH = NODE_H;
  protected readonly estados: TopologyNodeState[] = ['operativo', 'alerta', 'falla', 'desconectado'];

  /** Equipo cuyo panel de detalle está abierto (CGBIDA-364). */
  protected readonly seleccionado = signal<TopologyNode | null>(null);

  /**
   * Recarga de la topología.
   *
   * El mapa se pide una vez al entrar, pero la tabla del mantenedor vive en la misma
   * pantalla: al crear o editar una planta o una máquina, lo que se ve en el mapa queda
   * viejo. Este subject vuelve a disparar la petición sin recargar la página.
   */
  private readonly recarga$ = new Subject<void>();

  /** `initialValue` obliga a que el tipo no incluya `undefined`; de ahí la unión. */
  private readonly carga = toSignal(
    // `merge` con un primer valor da la carga inicial; cada `recarga$` pide de nuevo.
    merge(of(undefined), this.recarga$).pipe(
      switchMap(() =>
        this.topologyService.get().pipe(
          map((t): EstadoCarga => (t.nodos.length ? { tipo: 'listo', topologia: t } : { tipo: 'vacio' })),
          // El `catchError` va DENTRO del switchMap: si estuviera afuera, un fallo cerraría
          // el stream y las recargas posteriores no volverían a pedir nada.
          catchError(() => of<EstadoCarga>({ tipo: 'error' })),
        ),
      ),
    ),
    { initialValue: { tipo: 'cargando' } as EstadoCarga },
  );

  /** Vuelve a pedir el mapa. No toca la cámara: el zoom y el paneo se conservan. */
  protected recargarTopologia(): void {
    this.recarga$.next();
  }

  /** Tipo de estado actual: `cargando` · `error` · `vacio` · `listo`. */
  protected readonly estado = computed(() => this.carga().tipo);

  private readonly topologiaLista = computed(() => {
    const c = this.carga();
    return c.tipo === 'listo' ? c.topologia : null;
  });

  protected readonly nodos = computed<TopologyNode[]>(() => this.topologiaLista()?.nodos ?? []);
  protected readonly conexiones = computed<TopologyConnection[]>(
    () => this.topologiaLista()?.conexiones ?? [],
  );

  /** Centro de cada nodo, para dibujar las aristas entre centros y no entre esquinas. */
  private readonly centros = computed(() => {
    const mapa = new Map<string, { x: number; y: number }>();
    for (const n of this.nodos()) {
      mapa.set(n.nodo_id, { x: n.pos_x + NODE_W / 2, y: n.pos_y + NODE_H / 2 });
    }
    return mapa;
  });

  /** Aristas resueltas: se descartan las que apunten a un nodo ausente. */
  /**
   * Punto donde la recta centro→centro corta el borde de la tarjeta.
   *
   * Sin este recorte la arista termina en el centro del nodo destino y la punta de flecha
   * queda TAPADA por la tarjeta, que se dibuja después. El `AIRE_FLECHA` deja la punta
   * separada del borde para que se lea completa.
   */
  private bordeNodo(
    desde: { x: number; y: number },
    hasta: { x: number; y: number },
  ): { x: number; y: number } {
    const dx = hasta.x - desde.x;
    const dy = hasta.y - desde.y;
    const largo = Math.hypot(dx, dy);
    if (!largo) return { x: desde.x, y: desde.y };

    const ux = dx / largo;
    const uy = dy / largo;
    // Distancia del centro al borde del rectángulo en la dirección de la recta.
    const t = Math.min(
      Math.abs((NODE_W / 2) / (ux || Number.EPSILON)),
      Math.abs((NODE_H / 2) / (uy || Number.EPSILON)),
    );

    return { x: desde.x + ux * (t + AIRE_FLECHA), y: desde.y + uy * (t + AIRE_FLECHA) };
  }

  /**
   * Aristas resueltas: se descartan las que apunten a un nodo ausente y se recortan al
   * borde de la tarjeta para que la flecha quede a la vista.
   *
   * Cada arista viaja como una curva Bézier cúbica con los puntos de control en vertical:
   * sale hacia abajo desde el borde del nodo origen y entra en vertical al destino, así
   * que dos aristas que nacen del mismo nodo no se pisan en el primer tramo.
   */
  protected readonly aristas = computed(() => {
    const centros = this.centros();
    const r = (n: number) => Math.round(n * 100) / 100;
    return this.conexiones()
      .map((c) => {
        const o = centros.get(c.origen_nodo_id);
        const d = centros.get(c.destino_nodo_id);
        if (!o || !d) return null;
        const inicio = this.bordeNodo(o, d);
        const fin = this.bordeNodo(d, o);

        // El 45 % de la distancia vertical deja el tramo central recto y los extremos
        // curvos: es lo que separa visualmente un abanico de líneas rectas.
        const dy = fin.y - inicio.y;
        const c1 = { x: inicio.x, y: inicio.y + dy * 0.45 };
        const c2 = { x: fin.x, y: fin.y - dy * 0.45 };

        return {
          ...c,
          x1: inicio.x,
          y1: inicio.y,
          x2: fin.x,
          y2: fin.y,
          // Formato estable ("M x y C x y x y x y") para poder afirmarlo en los tests.
          d:
            `M ${r(inicio.x)} ${r(inicio.y)} ` +
            `C ${r(c1.x)} ${r(c1.y)} ${r(c2.x)} ${r(c2.y)} ${r(fin.x)} ${r(fin.y)}`,
        };
      })
      .filter((e): e is NonNullable<typeof e> => e !== null);
  });

  // --- Enfoque: al pasar el mouse por un nodo se enciende su rama ------------------

  /** Nodo bajo el cursor. `null` = sin foco. */
  protected readonly resaltado = signal<string | null>(null);

  /** Hijos por nodo, derivados de las aristas (origen → destino). */
  private readonly hijosPorNodo = computed(() => {
    const mapa = new Map<string, string[]>();
    for (const c of this.conexiones()) {
      const lista = mapa.get(c.origen_nodo_id) ?? [];
      lista.push(c.destino_nodo_id);
      mapa.set(c.origen_nodo_id, lista);
    }
    return mapa;
  });

  /** Padre de cada nodo. En esta jerarquía (planta → disciplina → máquina) hay uno solo. */
  private readonly padrePorNodo = computed(() => {
    const mapa = new Map<string, string>();
    for (const c of this.conexiones()) {
      if (!mapa.has(c.destino_nodo_id)) mapa.set(c.destino_nodo_id, c.origen_nodo_id);
    }
    return mapa;
  });

  /**
   * Nodos que forman la rama del nodo resaltado: él mismo, sus ancestros y todos sus
   * descendientes. Los hermanos quedan fuera a propósito: si se incluyeran, pasar el mouse
   * por una máquina encendería media planta y el enfoque perdería sentido.
   */
  protected readonly ramaEnFoco = computed<ReadonlySet<string>>(() => {
    const raiz = this.resaltado();
    if (!raiz) return new Set<string>();

    const rama = new Set<string>([raiz]);

    // Ancestros: sube hasta la planta.
    const padres = this.padrePorNodo();
    let actual = raiz;
    for (;;) {
      const padre = padres.get(actual);
      if (!padre || rama.has(padre)) break;
      rama.add(padre);
      actual = padre;
    }

    // Descendientes: baja por todas las ramas.
    const hijos = this.hijosPorNodo();
    const cola = [raiz];
    while (cola.length) {
      const nodo = cola.shift()!;
      for (const hijo of hijos.get(nodo) ?? []) {
        if (rama.has(hijo)) continue;
        rama.add(hijo);
        cola.push(hijo);
      }
    }

    return rama;
  });

  protected readonly hayFoco = computed(() => this.ramaEnFoco().size > 0);

  /** Una arista pertenece a la rama si sus dos extremos están dentro. */
  protected leToca(arista: { origen_nodo_id: string; destino_nodo_id: string }): boolean {
    const rama = this.ramaEnFoco();
    if (!rama.size) return false;
    return rama.has(arista.origen_nodo_id) && rama.has(arista.destino_nodo_id);
  }

  protected nodoEnFoco(nodo: { nodo_id: string }): boolean {
    const rama = this.ramaEnFoco();
    return !rama.size || rama.has(nodo.nodo_id);
  }

  // --- CGBIDA-363: cámara del lienzo -----------------------------------------

  /**
   * Rectángulo que contiene todos los nodos, con padding.
   *
   * Es la vista inicial y el destino del botón de reset. Se calcula a partir de las
   * posiciones que manda el backend, no de una constante: el mapa crece y se mueve, y una
   * vista fija deja nodos fuera de cuadro sin que nadie se entere.
   */
  protected readonly cajaContenido = computed(() => {
    const nodos = this.nodos();
    if (nodos.length === 0) return null;

    const minX = Math.min(...nodos.map((n) => n.pos_x));
    const minY = Math.min(...nodos.map((n) => n.pos_y));
    const maxX = Math.max(...nodos.map((n) => n.pos_x + NODE_W));
    const maxY = Math.max(...nodos.map((n) => n.pos_y + NODE_H));

    return {
      x: minX - PADDING_VISTA,
      y: minY - PADDING_VISTA,
      w: maxX - minX + 2 * PADDING_VISTA,
      h: maxY - minY + 2 * PADDING_VISTA,
    };
  });

  protected readonly viewBox = signal({ ...INITIAL_VIEW });
  protected readonly arrastrando = signal(false);
  private ultimoPunto = { x: 0, y: 0 };
  private svgEl: SVGSVGElement | null = null;

  protected readonly viewBoxAttr = computed(() => {
    const v = this.viewBox();
    return `${v.x} ${v.y} ${v.w} ${v.h}`;
  });

  protected zoom(factor: number): void {
    this.viewBox.update((v) => {
      const w = v.w / factor;
      const h = v.h / factor;
      return { x: v.x + v.w / 2 - w / 2, y: v.y + v.h / 2 - h / 2, w, h };
    });
  }

  /**
   * Zoom con la rueda (HU-07).
   *
   * Reutiliza `zoom()`, así que respeta el centro actual igual que los botones. El
   * `preventDefault` es imprescindible: sin él la rueda scrollea la página entera mientras
   * el usuario intenta acercarse al mapa.
   */
  protected onWheel(event: WheelEvent): void {
    event.preventDefault();
    // deltaY negativo = rueda hacia arriba = acercar.
    this.zoom(event.deltaY < 0 ? FACTOR_RUEDA : 1 / FACTOR_RUEDA);
  }

  /**
   * `textLength` para el nombre del nodo, o `null` si entra sin comprimir.
   *
   * Los nombres largos («Planta Central San Bernardo») se salían del rectángulo y se
   * montaban sobre el nodo vecino. Se estima el ancho con el tamaño real del texto (11 px,
   * peso 600) y, si excede el ancho útil, se devuelve ese ancho para que `lengthAdjust`
   * lo comprima. Con `null` Angular omite el atributo y el nombre se dibuja natural.
   */
  protected anchoNombre(nombre: string): number | null {
    const estimado = nombre.length * 11 * 0.56;
    return estimado > ANCHO_NOMBRE_NODO ? ANCHO_NOMBRE_NODO : null;
  }

  protected resetView(): void {
    // Vuelve al encuadre que contiene el grafo, no a una constante: si el mapa cambió,
    // el reset debe mostrar el mapa nuevo completo.
    const caja = this.cajaContenido();
    this.viewBox.set(caja ? { ...caja } : { ...INITIAL_VIEW });
  }

  protected onMouseDown(event: MouseEvent): void {
    const target = event.target as HTMLElement | null;
    if (target?.closest('.topo-node')) return; // los nodos no arrastran el lienzo
    this.arrastrando.set(true);
    this.ultimoPunto = { x: event.clientX, y: event.clientY };
  }

  protected onMouseMove(event: MouseEvent): void {
    if (!this.arrastrando()) return;
    this.svgEl = event.currentTarget as SVGSVGElement;
    const rect = this.svgEl.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    this.viewBox.update((v) => {
      // El delta de pantalla se escala a unidades del viewBox.
      const dx = ((event.clientX - this.ultimoPunto.x) * v.w) / rect.width;
      const dy = ((event.clientY - this.ultimoPunto.y) * v.h) / rect.height;
      return { ...v, x: v.x - dx, y: v.y - dy };
    });
    this.ultimoPunto = { x: event.clientX, y: event.clientY };
  }

  protected onMouseUp(): void {
    this.arrastrando.set(false);
  }

  // --- Táctil: arrastre con un dedo y pinza con dos ---------------------------
  //
  // El ratón se maneja arriba con eventos de mouse. En una pantalla táctil el dedo NO genera
  // mousemove al arrastrar (y `touch-action: none` desactiva el gesto nativo), así que sin esto el
  // mapa quedaba inmóvil. Se usan Pointer Events solo para `pointerType === 'touch'`, para no
  // duplicar lo que ya hacen los handlers de mouse.

  /** Dedos apoyados ahora mismo sobre el mapa. */
  private readonly dedos = new Map<number, { x: number; y: number }>();
  private distanciaPinza = 0;
  private inicioToque = { x: 0, y: 0 };
  /** El gesto fue un arrastre o una pinza: el «clic» que el navegador emite al soltar no debe abrir un nodo. */
  private gestoMovio = false;

  protected onPointerDown(event: PointerEvent): void {
    if (event.pointerType !== 'touch') return;
    if (this.dedos.size === 0) this.gestoMovio = false;
    this.dedos.set(event.pointerId, { x: event.clientX, y: event.clientY });
    if (this.dedos.size === 1) {
      this.inicioToque = { x: event.clientX, y: event.clientY };
      this.ultimoPunto = { x: event.clientX, y: event.clientY };
      this.arrastrando.set(true);
    } else if (this.dedos.size === 2) {
      this.distanciaPinza = this.distanciaEntreDedos();
      this.ultimoPunto = this.centroDeDedos();
    }
  }

  protected onPointerMove(event: PointerEvent): void {
    if (event.pointerType !== 'touch' || !this.dedos.has(event.pointerId)) return;
    this.dedos.set(event.pointerId, { x: event.clientX, y: event.clientY });
    const svg = event.currentTarget as SVGSVGElement;
    const rect = svg.getBoundingClientRect();
    if (!rect.width || !rect.height) return;

    if (this.dedos.size >= 2) {
      // Pinza: acerca o aleja alrededor del punto medio de los dos dedos, y arrastra con él.
      const distancia = this.distanciaEntreDedos();
      const centro = this.centroDeDedos();
      if (this.distanciaPinza > 0 && distancia > 0) {
        this.camaraTactil(rect, this.ultimoPunto, centro, distancia / this.distanciaPinza);
      }
      this.distanciaPinza = distancia;
      this.ultimoPunto = centro;
      this.gestoMovio = true;
      return;
    }

    // Un dedo: arrastra el lienzo (el ancla del gesto es la última posición conocida).
    if (Math.hypot(event.clientX - this.inicioToque.x, event.clientY - this.inicioToque.y) > UMBRAL_TOQUE_PX) this.gestoMovio = true;
    if (this.gestoMovio) this.camaraTactil(rect, this.ultimoPunto, { x: event.clientX, y: event.clientY }, 1);
    this.ultimoPunto = { x: event.clientX, y: event.clientY };
  }

  protected onPointerEnd(event: PointerEvent): void {
    if (event.pointerType !== 'touch') return;
    this.dedos.delete(event.pointerId);
    this.distanciaPinza = 0;
    if (this.dedos.size === 0) {
      this.arrastrando.set(false);
    } else {
      // Queda un dedo tras una pinza: se re-ancla a él para que la vista no «salte».
      this.ultimoPunto = this.centroDeDedos();
    }
  }

  private distanciaEntreDedos(): number {
    const [a, b] = [...this.dedos.values()];
    return a && b ? Math.hypot(a.x - b.x, a.y - b.y) : 0;
  }

  private centroDeDedos(): { x: number; y: number } {
    const puntos = [...this.dedos.values()];
    const n = puntos.length || 1;
    return { x: puntos.reduce((suma, p) => suma + p.x, 0) / n, y: puntos.reduce((suma, p) => suma + p.y, 0) / n };
  }

  /**
   * Mueve la cámara con un gesto táctil. El punto del mapa que estaba bajo `desde` (px de pantalla) queda
   * bajo `hasta`, y la vista se acerca (`factor` > 1) o se aleja (`factor` < 1). Con `desde === hasta` es
   * una pinza pura; con `factor === 1` es un arrastre puro; y los dos a la vez cuando los dedos se separan
   * y se desplazan.
   *
   * Con `preserveAspectRatio="meet"` el mapa se dibuja con UNA escala uniforme y queda centrado con bandas
   * vacías, por eso se convierte pantalla -> unidades del viewBox con esa escala y ese desfase.
   */
  private camaraTactil(rect: DOMRect, desde: { x: number; y: number }, hasta: { x: number; y: number }, factor: number): void {
    this.viewBox.update((v) => {
      const aMapa = (caja: { x: number; y: number; w: number; h: number }, px: number, py: number) => {
        const escala = Math.max(caja.w / rect.width, caja.h / rect.height);
        const margenX = (rect.width - caja.w / escala) / 2;
        const margenY = (rect.height - caja.h / escala) / 2;
        return { x: caja.x + (px - rect.left - margenX) * escala, y: caja.y + (py - rect.top - margenY) * escala, escala, margenX, margenY };
      };
      const f = Math.min(Math.max(factor, 0.5), 2); // un gesto brusco no debe disparar la vista
      const punto = aMapa(v, desde.x, desde.y);
      const w = v.w / f;
      const h = v.h / f;
      const escala = Math.max(w / rect.width, h / rect.height);
      const margenX = (rect.width - w / escala) / 2;
      const margenY = (rect.height - h / escala) / 2;
      return { x: punto.x - (hasta.x - rect.left - margenX) * escala, y: punto.y - (hasta.y - rect.top - margenY) * escala, w, h };
    });
  }

  // --- CGBIDA-364: panel de detalle ------------------------------------------

  protected seleccionar(nodo: TopologyNode, event: Event): void {
    // Sin esto, el clic burbujearía al <svg> y arrancaría un paneo.
    event.stopPropagation();
    // Al soltar un arrastre táctil el navegador emite un «clic» sobre el nodo que quedó bajo el dedo.
    if (this.gestoMovio) {
      this.gestoMovio = false;
      return;
    }
    this.seleccionado.set(nodo);
    this.pila.set([nodo]);
  }

  protected cerrarPanel(): void {
    this.seleccionado.set(null);
    this.pila.set([]);
    this.otEnDetalle.set(null);
  }

  // --- CGBIDA-384: navegación por la jerarquía -------------------------------

  /**
   * Pila de nodos visitados, para poder volver al padre.
   * DEBE ser una señal: `esBotonVolver` es un `computed` y con un array plano se
   * memorizaría con el valor de la primera lectura (no hay señal que lo invalide).
   */
  private readonly pila = signal<TopologyNode[]>([]);

  protected readonly esBotonVolver = computed(() => this.pila().length > 1);

  /** Cambia el nodo del panel a uno de sus hijos (CGBIDA-384). */
  protected seleccionarHijo(hijo: TopologyNode): void {
    this.seleccionado.set(hijo);
    this.pila.update((p) => [...p, hijo]);
  }

  protected volver(): void {
    this.pila.update((p) => p.slice(0, -1));
    const pila = this.pila();
    this.seleccionado.set(pila[pila.length - 1] ?? null);
  }

  // --- CGBIDA-382/383: detalle del nodo, órdenes e hijos ---------------------

  /**
   * Detalle del nodo seleccionado. Se recarga cada vez que cambia la selección,
   * así que navegar a un hijo pide el detalle de ese hijo.
   */
  private readonly detalle = signal<TopologyNodoDetalle | null>(null);

  private readonly cargandoDetalle = signal(false);
  private readonly errorDetalle = signal(false);

  constructor() {
    // Encuadre inicial: cuando llegan los nodos, la cámara se ajusta al grafo completo.
    // Corre una sola vez porque `cajaContenido` depende únicamente de `nodos`, que se
    // resuelve con la carga; después el usuario manda con el zoom y el paneo.
    effect(() => {
      const caja = this.cajaContenido();
      if (caja) this.viewBox.set(caja);
    });

    effect((onCleanup) => {
      const nodo = this.seleccionado();
      if (!nodo) {
        this.detalle.set(null);
        this.errorDetalle.set(false);
        return;
      }
      this.cargandoDetalle.set(true);
      const sub = this.topologyService.getNodo(nodo.nodo_id).subscribe({
        next: (d) => {
          this.detalle.set(d);
          this.errorDetalle.set(false);
          this.cargandoDetalle.set(false);
        },
        error: () => {
          this.errorDetalle.set(true);
          this.cargandoDetalle.set(false);
        },
      });
      onCleanup(() => sub.unsubscribe());
    });
  }

  /** `listo` solo cuando el detalle cargado corresponde al nodo seleccionado. */
  private readonly detalleDelSeleccionado = computed(() => {
    const d = this.detalle();
    const n = this.seleccionado();
    return d && n && d.nodo.nodo_id === n.nodo_id ? d : null;
  });

  protected readonly estadoDetalle = computed<'cargando' | 'error' | 'listo'>(() => {
    if (this.errorDetalle()) return 'error';
    return this.detalleDelSeleccionado() ? 'listo' : 'cargando';
  });

  protected readonly hijos = computed<TopologyNode[]>(
    () => this.detalleDelSeleccionado()?.hijos ?? [],
  );

  /**
   * Órdenes agrupadas para el panel. La agrupación la decide `filterGroup()`, no este
   * componente: si se reimplementara aquí, el panel y el listado de OTs podrían
   * discrepar sobre en qué grupo cae `assigned` u `overdue` (CGBIDA-378, D1).
   */
  protected readonly gruposDeOrdenes = computed<GrupoEnPanel[]>(() => {
    const ordenes = this.detalleDelSeleccionado()?.ordenes ?? [];
    const porGrupo = new Map<GrupoOt, OtEnPanel[]>();

    for (const orden of ordenes) {
      const clave = CLAVE_GRUPO[filterGroup(orden.estado as WorkOrderStatus)] ?? 'groupPendientes';
      const lista = porGrupo.get(clave) ?? [];
      lista.push({
        orden,
        // `overdue` va en Pendientes pero con badge rojo (CGBIDA-378).
        vencida: orden.estado === 'overdue',
        etiqueta: ETIQUETA_OT[orden.estado] ?? orden.estado,
        color: COLOR_OT[orden.estado] ?? COLOR_OT['pending'],
      });
      porGrupo.set(clave, lista);
    }

    // El Map conserva el orden de inserción, así que se recorren los grupos en el
    // orden de presentación y se descartan los vacíos.
    return ORDEN_GRUPOS.filter((g) => porGrupo.has(g)).map((nombre) => ({
      nombre,
      ordenes: porGrupo.get(nombre)!,
    }));
  });

  /** Grupo elegido en el selector. `todos` deja el listado completo. */
  protected readonly filtroEstado = signal<GrupoOt | 'todos'>('todos');

  /** Orden aplicado DENTRO de cada grupo; el orden de los grupos no cambia. */
  protected readonly ordenOt = signal<OrdenOt>('recientes');

  /**
   * Grupos plegados.
   *
   * «Cerradas» y «Canceladas» arrancan cerradas porque son las que sepultan lo accionable:
   * con 26 cerradas, las 2 pendientes y la 1 en curso quedaban a cuatro pantallas de scroll
   * en un panel de 476 px.
   */
  private readonly plegados = signal<Record<GrupoOt, boolean>>({
    groupPendientes: false,
    groupEnCurso: false,
    groupCerradas: true,
    groupCanceladas: true,
  });

  protected estaPlegado(grupo: GrupoOt): boolean {
    return this.plegados()[grupo];
  }

  protected alternarGrupo(grupo: GrupoOt): void {
    this.plegados.update((p) => ({ ...p, [grupo]: !p[grupo] }));
  }

  protected cambiarFiltro(valor: string): void {
    this.filtroEstado.set(valor === 'todos' ? 'todos' : (valor as GrupoOt));
  }

  protected alternarOrden(): void {
    this.ordenOt.update((o) => (o === 'az' ? 'recientes' : 'az'));
  }

  /** Etiqueta del botón de orden: muestra el criterio activo, no el que aplicaría. */
  protected readonly etiquetaOrden = computed(() =>
    this.ordenOt() === 'az' ? this.t().sortAz : this.t().sortRecent,
  );

  /** Total de OTs del equipo, para el contador de la opción «Todos». */
  protected readonly totalOrdenes = computed(() =>
    this.gruposDeOrdenes().reduce((n, g) => n + g.ordenes.length, 0),
  );

  /**
   * Grupos tal como se pintan: filtrados por estado y con las OTs ordenadas por dentro.
   *
   * El filtro NO reordena los grupos ni los fusiona: sólo descarta los que no coinciden.
   */
  protected readonly gruposVisibles = computed<GrupoEnPanel[]>(() => {
    const filtro = this.filtroEstado();
    const orden = this.ordenOt();
    const grupos = this.gruposDeOrdenes();
    const visibles = filtro === 'todos' ? grupos : grupos.filter((g) => g.nombre === filtro);

    const comparar = (a: OtEnPanel, b: OtEnPanel): number => {
      if (orden === 'az') return a.orden.numero_ot.localeCompare(b.orden.numero_ot);
      // Más recientes primero. Una fecha ilegible cae al final en vez de romper el orden.
      const fa = Date.parse(a.orden.created_at) || 0;
      const fb = Date.parse(b.orden.created_at) || 0;
      return fb - fa;
    };

    return visibles.map((g) => ({ ...g, ordenes: [...g.ordenes].sort(comparar) }));
  });

  // --- CGBIDA-385: detalle de una OT -----------------------------------------

  /** OT abierta en el sheet de detalle. El sheet se reutiliza, no se reimplementa. */
  protected readonly otEnDetalle = signal<WorkOrder | null>(null);

  protected abrirDetalleOt(orden: WorkOrder): void {
    this.otEnDetalle.set(orden);
  }

  protected cerrarDetalleOt(): void {
    this.otEnDetalle.set(null);
  }

  // --- helpers de presentación ----------------------------------------------

  protected colorDe(estado: TopologyNodeState): string {
    return COLOR_POR_ESTADO[estado] ?? COLOR_POR_ESTADO.desconectado;
  }

  protected etiquetaDe(estado: TopologyNodeState): string {
    const clave = CLAVE_ESTADO[estado] ?? CLAVE_ESTADO.desconectado;
    const textos = this.t() as unknown as Record<string, string>;
    return textos[clave] ?? estado;
  }
}






