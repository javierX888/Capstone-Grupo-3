import { Component, computed, inject, signal, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StatsService } from '../../core/services/stats.service';
import { CurrencyService } from '../../core/services/currency.service';
import { MtbfUnitService, UnidadMtbf } from '../../core/services/mtbf-unit.service';
import {
  FinancialStats,
  FiltrosDashboard,
  RangoTemporal,
  SIN_FILTROS,
} from '../../core/models';
import { I18nService } from '../../core/i18n/i18n.service';
import { SaludOperacionalComponent } from './components/salud-operacional/salud-operacional.component';
import { MachineRankingComponent } from './components/machine-ranking/machine-ranking.component';
import { TipoDonutComponent } from './components/tipo-donut/tipo-donut.component';
import { AlertaEstancadasComponent } from './components/alerta-estancadas/alerta-estancadas.component';
import { CostoDetalleComponent } from './components/costo-detalle/costo-detalle.component';
import { SlaHistoricoComponent } from './components/sla-historico/sla-historico.component';
import { TopMaquinasComponent } from './components/top-maquinas/top-maquinas.component';
import { ExplicameComponent } from './explicame/explicame.component';
import { FiltrosDashboardComponent } from './components/filtros-dashboard/filtros-dashboard.component';

/**
 * Dashboard de KPIs (HU-08 + HU-16 / CGBIDA-392 y 393).
 *
 * Los 6 indicadores en tarjetas, cada una con su valor y la descripcion de QUE mide.
 * Debajo, el grafico de backlog de 14 dias.
 *
 * El texto sale de i18n (es/en) y todo tiene variantes de modo oscuro.
 *
 * Estados:
 *  - Cargando: texto explicito, nunca ceros.
 *  - Error: mensaje claro. Esta rama era INALCANZABLE antes de CGBIDA-403, porque el
 *    backend devolvia HTTP 200 con ceros y el error nunca llegaba. Ahora devuelve 503/500.
 */
@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, MachineRankingComponent, TipoDonutComponent, AlertaEstancadasComponent, CostoDetalleComponent, SaludOperacionalComponent, SlaHistoricoComponent, TopMaquinasComponent, ExplicameComponent, FiltrosDashboardComponent],
  template: `
    <!--
      max-w-screen-2xl (1536px) + mx-auto: sin esto el dashboard se estiraba al 100% del
      ancho y en monitores anchos las tarjetas quedaban desproporcionadas y los graficos
      con demasiado aire. 1536px es el ancho estandar de dashboard de Tailwind y deja
      margen a los dos lados en un monitor de 1920.
    -->
    <div class="mx-auto flex w-full max-w-screen-2xl flex-col gap-3">
      <div class="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 class="text-2xl font-bold text-tinta ">{{ t().dashboardTitle }}</h1>
          <p class="text-sm text-tinta-suave ">{{ t().dashboardSubtitle }}</p>
        </div>

        <!--
          Los controles (moneda y rango) viven en el panel de filtros (CGBIDA-550). Aca
          queda solo la tasa aplicada, que es un dato de lectura: sin esto el usuario no
          sabe a que tipo de cambio se convirtieron las cifras.
        -->
        <div class="flex flex-wrap items-center justify-end gap-2">
          @if (stats(); as s) {
            <app-explicame [stats]="s" [rango]="rango()" [etiquetaRango]="etiquetaRango(rango())" (verCostos)="abrirCostos()" />
          }
          @if (currency.sinTasa()) {
            <p class="text-sm text-media " data-testid="moneda-sin-tasa">
              {{ t().currencyNoRate }}
            </p>
          } @else if (currency.moneda() === 'USD') {
            <p class="text-sm text-tinta-suave " data-testid="moneda-tasa">
              {{ t().currencyRate }} {{ tasaTexto() }} CLP/USD
            </p>
          }
        </div>
      </div>

      <!-- Panel de filtros globales (CGBIDA-550): planta, disciplina y maquina. -->
      <app-filtros-dashboard (cambio)="onFiltros($event)" />

      @if (loading()) {
        <div class="py-10 text-center text-tinta-suave " role="status">
          {{ t().loading }}
        </div>
      } @else if (error()) {
        <div
          class="rounded-control border border-peligro bg-peligro-suave p-6 text-center text-peligro
                   "
          role="alert"
        >
          {{ t().loadError }}
        </div>
      } @else {
        <!-- Banner de estancadas (CGBIDA-396). Se auto-oculta si no hay ninguna. -->
        <app-alerta-estancadas [datos]="estancadas()" />
        <!--
          KPIs: 5 en una sola fila desde xl. Se quito el de Impacto Anual porque el
          grafico de escenarios de abajo ya lo explica con mas detalle; con 5 columnas
          cada tarjeta gana ancho y la fila queda continua (6 columnas dejaria un hueco).
        -->
        <div class="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5" data-tour="dash-kpis">
          @for (kpi of tarjetas(); track kpi.clave) {
            <div
              class="rounded-control border border-borde bg-superficie p-3 
                      "
              [attr.data-testid]="'kpi-' + kpi.clave"
              [attr.data-tour]="kpi.clave === 'costo' ? 'dash-costo' : null"
            >
              <div class="flex items-start justify-between gap-1">
                <div class="flex min-w-0 items-center gap-1">
                  <p class="truncate text-sm text-tinta-suave ">
                    {{ kpi.etiqueta }}
                  </p>
                  <!--
                    Selector de unidad del MTBF (CGBIDA-435). Va en la MISMA linea de la
                    etiqueta y con alto fijo de 16 px, para no sumar altura: el dashboard
                    esta en 0 px de desborde y un renglon mas lo rompe.
                  -->
                  @if (kpi.clave === 'mtbf') {
                    <select
                      [attr.aria-label]="t().mtbfUnitLabel"
                      [attr.data-testid]="'selector-unidad-mtbf'"
                      (change)="cambiarUnidadMtbf($any($event.target).value)"
                      class="h-5 shrink-0 cursor-pointer rounded-control border border-borde-control
                             bg-superficie-alt px-1.5 text-xs leading-none
                             text-tinta-suave outline-none focus:border-accion
                              "
                    >
                      @for (u of unidadesMtbf; track u) {
                        <option [value]="u" [selected]="u === mtbf.unidad()"
                                [attr.data-testid]="'unidad-' + u">
                          {{ etiquetaUnidadMtbf(u) }}
                        </option>
                      }
                    </select>
                  }
                </div>
                <!--
                  El Costo Directo no lleva '?': su boton 'Ver detalle' abre el desglose
                  completo, que dice más que el tooltip y no duplica el affordance
                  (CGBIDA-550). En el resto de las tarjetas el '?' explica la formula.
                -->
                @if (kpi.tooltip && kpi.clave !== 'costo') {
                  <div class="group relative shrink-0">
                    <button
                      type="button"
                      class="flex h-4 w-4 items-center justify-center rounded-full border
                             border-borde-control text-sm font-bold leading-none text-tinta-suave
                             transition-colors hover:border-accion hover:text-accion
                             focus:border-accion focus:text-accion focus:outline-none
                              "
                      [attr.aria-describedby]="'kpi-tip-' + kpi.clave"
                      [attr.aria-label]="kpi.etiqueta"
                      [attr.data-testid]="'info-kpi-' + kpi.clave"
                    >?</button>
                    <div
                      role="tooltip"
                      [id]="'kpi-tip-' + kpi.clave"
                      [attr.data-testid]="'tooltip-kpi-' + kpi.clave"
                      class="pointer-events-none invisible absolute right-0 top-full z-50 mt-2 w-64
                             rounded-control border border-borde bg-superficie p-3 text-sm font-normal
                             normal-case leading-relaxed text-tinta-suave shadow-lg
                             group-hover:visible group-focus-within:visible
                               "
                    >{{ kpi.tooltip }}</div>
                  </div>
                }
              </div>
              <p class="mt-1 text-2xl font-bold" [class]="kpi.color">{{ kpi.valor }}</p>
              <p class="mt-1 text-sm text-tinta-suave ">{{ kpi.descripcion }}</p>
              <!--
                Detalle de costos (CGBIDA-518). El boton vive SOLO en la tarjeta de Costo
                Directo y abre un modal con el desglose por maquina.
              -->
              @if (kpi.clave === 'costo') {
                <button
                  type="button"
                  (click)="abrirCostos()"
                  class="mt-2 inline-flex items-center gap-1 rounded-control border
                         border-borde-control px-2 py-1 text-sm font-semibold text-accion
                         transition-colors hover:border-accion focus:border-accion
                         focus:outline-none"
                  data-testid="ver-detalle-costos"
                  data-tour="dash-costo-detalle"
                >{{ t().costDetailButton }}</button>
              }
            </div>
          }
        </div>

        <!--
          Gráficos en grid, como el legacy (Dashboard.tsx:290 + .dash-charts-grid).

          Con los gráficos apilados a todo el ancho, cada SVG con w-full se escalaba al
          ancho de la pantalla: el backlog mide 720x240 y el ranking 420x240, así que a
          1536 px quedaban de 512 y 878 px de alto. De ahí la sensación de "gigante".

          En dos columnas cada uno vuelve a su tamaño natural: el backlog queda en ~253 px
          de alto y el ranking en ~297 px. La dona va abajo ocupando las dos columnas,
          porque su contenido (dona de 200 px + leyenda de 214 px) es angosto y se centra.
        -->
        <div class="grid grid-cols-1 gap-4 lg:grid-cols-2">
          <!-- Evolucion del SLA (CGBIDA-515). Ocupa las dos columnas: el eje X necesita
               ancho para las etiquetas de periodo y la linea se lee mejor. -->
          <app-sla-historico class="min-w-0 lg:col-span-2" [filtros]="filtros()" />

          <!-- Salud Operacional (CGBIDA-520): semaforo simplificado con el motivo. -->
          <app-salud-operacional class="min-w-0" data-tour="dash-salud" [salud]="salud()" />

          <!-- El ranking muestra su propio estado vacío si no hay equipos. -->
          <app-machine-ranking
            class="min-w-0"
            [maquinas]="equipos()"
            [maquinasPorCosto]="equiposPorCosto()"
            [verFinanzas]="verFinanzas()"
          />

          <!-- Top 5 por maquina (CGBIDA-516 y 517): peor MTTR y peor MTBF. -->
          <app-top-maquinas class="min-w-0" data-tour="dash-top5" [mttr]="peorMttr()" [mtbf]="peorMtbf()" />

          <!-- Dona por tipo de intervencion (CGBIDA-395). Se auto-oculta sin datos. -->
          <app-tipo-donut class="min-w-0" [datos]="porTipo()" />
        </div>

        <!-- Modal de costos desglosados (CGBIDA-518). -->
        <app-costo-detalle
          [abierto]="modalCostos()"
          [maquinas]="equiposPorCosto()"
          (cerrar)="cerrarCostos()"
        />
      }
    </div>
  `
})
export class DashboardComponent implements OnInit {
  private statsService = inject(StatsService);
  private i18n = inject(I18nService);

  /** Moneda de presentación (CGBIDA-432). Los datos base son CLP. */
  protected readonly currency = inject(CurrencyService);

  /**
   * Unidad del MTBF (CGBIDA-435). Estado compartido con el semáforo: el mismo MTBF
   * aparece en la tarjeta y en el desglose de salud, y verlo en dos unidades distintas
   * se lee como un error.
   */
  protected readonly mtbf = inject(MtbfUnitService);

  /** Opciones del selector de unidad, en orden. */
  protected readonly unidadesMtbf: readonly UnidadMtbf[] = ['horas', 'dias', 'meses'];

  stats = signal<FinancialStats | null>(null);
  loading = signal(true);
  error = signal(false);

  /**
   * Rango temporal activo (CGBIDA-550).
   *
   * Ya no es un signal propio: lo elige el panel de filtros y viaja dentro de
   * `FiltrosDashboard`. Se deriva para no tener dos fuentes de verdad del mismo valor.
   */
  protected readonly rango = computed<RangoTemporal>(() => this.filtros().rango);

  /**
   * Filtros de topologia activos (CGBIDA-550).
   *
   * Viven aca y no en el panel porque el Dashboard es el duenio de las peticiones: el
   * panel solo avisa que cambiaron, y este componente vuelve a pedir los KPIs y se los
   * pasa al grafico historico por input.
   */
  protected readonly filtros = signal<FiltrosDashboard>(SIN_FILTROS);

  /** Textos del bloque `dashboard` (títulos, avisos y etiquetas del selector). */
  protected readonly tr = computed(() => this.i18n.tree().dashboard);

  /**
   * Etiqueta legible de cada período. La usan el botón «Explícame» y el gráfico histórico,
   * así que tiene que decir lo mismo que el selector del panel de filtros.
   */
  protected etiquetaRango(r: RangoTemporal): string {
    const t = this.tr();
    switch (r) {
      case 7:
        return t.last7Days;
      case 'mes':
        return t.groupByMonth;
      case 'semestre':
        return t.groupBySemester;
      case 'anio':
        return t.groupByYear;
      case 'cinco':
        return t.groupBy5Years;
      default:
        return t.allTime;
    }
  }

  /** Textos del bloque `financial`. Reactivo al cambio de idioma. */
  protected readonly t = computed(() => this.i18n.tree().financial);

  /** Equipos del ranking. El backend ya los limita a 5. */
  protected readonly equipos = computed(() => this.stats()?.machines ?? []);

  /** Top 5 por costo real, que no coincide con el top 5 por volumen (CGBIDA-435). */
  protected readonly equiposPorCosto = computed(() => this.stats()?.machines_por_costo ?? []);

  /** Top 5 con peor MTTR: las que mas tardan en repararse (CGBIDA-516). */
  protected readonly peorMttr = computed(() => this.stats()?.top_5_peor_mttr ?? []);

  /** Top 5 con peor MTBF: las que menos aguantan sin fallar (CGBIDA-517). */
  protected readonly peorMtbf = computed(() => this.stats()?.top_5_peor_mtbf ?? []);

  /** Distribucion por tipo de intervencion, para la dona. */
  protected readonly porTipo = computed(() => this.stats()?.por_tipo ?? []);

  /** Semaforo simplificado de salud operacional (CGBIDA-520). */
  protected readonly salud = computed(() => this.stats()?.salud_operacional ?? null);

  /** Visibilidad del modal de costos desglosados (CGBIDA-518). */
  protected readonly modalCostos = signal(false);

  /** Ordenes estancadas para el banner. Un total de 0 lo oculta. */
  protected readonly estancadas = computed(
    () => this.stats()?.estancadas ?? { total: 0, vencidas: 0, demoradas: 0, umbral_dias: 0 }
  );

  /**
   * Las 5 tarjetas de KPI, derivadas de la respuesta.
   *
   * La descripcion (`*Sub`) es lo que pide la HU: que cada indicador diga que mide.
   * El MTBF tiene dos estados: valor, o aviso de que falta historial (`mtbf_visible`).
   *
   * La tarjeta de Impacto Anual se quito en CGBIDA-435: el grafico de escenarios de abajo
   * muestra la misma cifra con mas contexto, y su explicacion se mudo al grafico.
   */
  protected readonly tarjetas = computed(() => {
    const s = this.stats();
    if (!s) return [];
    const f = s.financials;
    const tx = this.t();
    const mtbfOk = f.mtbf_visible && f.mtbfHours !== null;

    // Moneda: los montos base estan en CLP y el servicio formatea en la activa.
    // Leer `formatear` dentro del computed lo hace reactivo al toggle.
    const cifra = (v: number) => this.currency.formatear(v);

    // La nota de moneda sigue viva en el tooltip del Costo Directo (CGBIDA-435).
    const notaMoneda =
      this.currency.moneda() === 'USD' && !this.currency.sinTasa() ? ` ${tx.kpiUsdNote}` : '';

    const todas = [
      // Orden pedido en el rediseno (CGBIDA-515): el SLA primero, que es el indicador
      // que el supervisor mira al entrar. Despues la Disponibilidad, que reemplaza al
      // Ahorro Generado (CGBIDA-519) por no depender de una tarifa supuesta.
      {
        clave: 'sla',
        etiqueta: tx.efficiency,
        valor: `${f.efficiency}%`,
        descripcion: tx.efficiencySub,
        color: 'text-ok ',
        tooltip: '',
      },
      {
        clave: 'disponibilidad',
        etiqueta: tx.disponibilidadPlanta,
        valor: `${(f.disponibilidad_planta ?? 0).toFixed(1)}%`,
        descripcion: tx.disponibilidadSub,
        color: 'text-ok ',
        tooltip: '',
      },
      {
        clave: 'mttr',
        etiqueta: tx.mttrGlobal,
        valor: `${f.mttr}m`,
        descripcion: tx.mttrSub,
        color: 'text-tinta ',
        tooltip: '',
      },
      {
        clave: 'costo',
        etiqueta: tx.directCost,
        valor: cifra(f.costo_total_acumulado ?? 0),
        descripcion: tx.directCostSub,
        color: 'text-tinta ',
        tooltip: `${tx.kpiCostoTooltip}${notaMoneda}`,
        accion: null,
      },
      {
        clave: 'mtbf',
        etiqueta: tx.mtbf,
        // CGBIDA-435: la unidad la elige el usuario. El servicio convierte desde horas
        // y el sufijo sale de i18n, asi que la tarjeta no sabe de conversiones.
        valor: mtbfOk
          ? this.mtbf.formatear(f.mtbfHours as number, this.sufijoMtbf())
          : tx.mtbfNeedData,
        descripcion: tx.mtbfSub,
        color: mtbfOk
          ? 'text-tinta '
          : 'text-sm font-medium text-media ',
        tooltip: '',
      }
    ];
    // El costo directo es financiero: el backend no lo manda a quien no es gerente, y acá no se dibuja.
    return this.verFinanzas() ? todas : todas.filter(t => t.clave !== 'costo');
  });

  /** Costo directo y ranking por costo: solo si el backend los entregó (gerente). */
  protected readonly verFinanzas = computed(() => this.stats()?.financieros_visibles !== false);

  ngOnInit() {
    // La tasa se pide en el componente, no en el servicio: asi el arranque es explicito
    // y los tests controlan cuando ocurre la peticion.
    void this.currency.asegurarTasa();
    this.cargar();
  }

  /** El panel de filtros cambio: se guardan y se vuelven a pedir los KPIs. */
  protected onFiltros(nuevos: FiltrosDashboard): void {
    this.filtros.set(nuevos);
    this.cargar();
  }

  /** Abre el modal de costos desglosados (CGBIDA-518). */
  protected abrirCostos(): void {
    this.modalCostos.set(true);
  }

  /** Cierra el modal (X, ESC o clic en el overlay). */
  protected cerrarCostos(): void {
    this.modalCostos.set(false);
  }

  /** Cambia la unidad del MTBF. El semáforo la refleja porque comparte el servicio. */
  protected cambiarUnidadMtbf(valor: string): void {
    if (valor === 'horas' || valor === 'dias' || valor === 'meses') {
      this.mtbf.setUnidad(valor);
    }
  }

  /** Etiqueta del selector de unidad, en el idioma activo. */
  protected etiquetaUnidadMtbf(u: UnidadMtbf): string {
    const t = this.t();
    switch (u) {
      case 'horas':
        return t.mtbfUnitHoras;
      case 'meses':
        return t.mtbfUnitMeses;
      default:
        return t.mtbfUnitDias;
    }
  }

  /** Sufijo corto que acompaña al valor del MTBF en la tarjeta. */
  protected readonly sufijoMtbf = computed(() => {
    const t = this.t();
    switch (this.mtbf.unidad()) {
      case 'horas':
        return t.mtbfUnitShortHoras;
      case 'meses':
        return t.mtbfUnitShortMeses;
      default:
        return t.mtbfUnitShortDias;
    }
  });

  /** Tasa vigente con dos decimales y coma decimal, como se lee en Chile. */
  protected readonly tasaTexto = computed(() => {
    const t = this.currency.tasa();
    if (t === null) return '';
    return new Intl.NumberFormat('es-CL', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(t);
  });

  private cargar(): void {
    this.loading.set(true);
    this.error.set(false);
    this.statsService.getFinancialImpact(this.filtros()).subscribe({
      next: (data) => {
        this.stats.set(data);
        this.loading.set(false);
      },
      error: () => {
        // No se muestran ceros: se muestra que no se pudo cargar.
        this.error.set(true);
        this.loading.set(false);
      }
    });
  }
}




