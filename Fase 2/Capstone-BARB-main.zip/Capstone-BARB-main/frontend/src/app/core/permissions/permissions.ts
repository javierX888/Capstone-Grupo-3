// =============================================================================
// MATRIZ DE PERMISOS — Espejo exacto de backend/core/permissions.py
// =============================================================================
//
// Fuente de verdad del frontend. Cualquier cambio debe hacerse también en
// permissions.py del backend, y viceversa. El backend aplica los permisos
// realmente vía require_route/require_action; este archivo solo controla
// qué se muestra en la UI para no exponer botones que el servidor rechazaría.
//

import { Role } from '../models';

export const ROLES = [
  'operador',
  'tecnico',
  'supervisor',
  'engineer',
  'gerente',
  'admin',
  'super_usuario',
] as const;

export type PermisoValor = boolean | 'ver';

export type RutaKey =
  | 'menu'
  | 'docchat'
  | 'debug'
  | 'topology'
  | 'memory'
  | 'report'
  | 'dashboard'
  | 'history'
  | 'empresas'
  | 'transacciones'
  | 'transacciones_empresa'
  | 'usuarios'
  | 'plantas'
  | 'avisos'
  | 'documentos';

export type AccionKey =
  | 'crear_ot'
  | 'cambiar_estado_ot'
  | 'cancelar_ot'
  | 'eliminar_ot'
  | 'subir_documentos'
  | 'gestionar_usuarios'
  | 'ver_usuarios'
  | 'eliminar_documentos'
  | 'gestionar_empresas'
  | 'reportar_falla'
  | 'gestionar_avisos'
  | 'asignar_ot'
  | 'ver_kpis_financieros'
  | 'iniciar_ot_asignada';

// =============================================================================
// MATRIZ DE RUTAS (idéntica a RUTAS en permissions.py)
// =============================================================================

export const RUTAS: Record<RutaKey, Record<string, PermisoValor>> = {
  menu:      { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: true, super_usuario: false },
  docchat:   { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: true, super_usuario: false },
  debug:     { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: true, super_usuario: false },
  topology:  { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: true, super_usuario: false },
  memory:    { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: true, super_usuario: false },
  report:    { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: true, super_usuario: false },
  dashboard: { operador: false, tecnico: false, supervisor: true,  engineer: true,  gerente: true,  admin: false, super_usuario: false },
  // Multi-empresa (espejo de permissions.py)
  empresas:   { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: false, admin: false, super_usuario: true },
  usuarios:   { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: true, admin: true,  super_usuario: true },
  documentos: { operador: 'ver',  tecnico: 'ver',  supervisor: 'ver',  engineer: true,  gerente: 'ver',  admin: true,  super_usuario: false },
  transacciones: { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: false, admin: false, super_usuario: true },
  transacciones_empresa: { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: true, admin: false, super_usuario: false },
  // plantas: mantenedor masivo de plantas, disciplinas y máquinas (HU-25 / CGBIDA-461).
  // Espejo de `RUTAS["plantas"]` en el backend: sólo el admin.
  plantas:    { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: false, admin: true,  super_usuario: false },
  // history: supervisor, ingeniero y gerente analizan el historial de fallas; el administrador no lo ve.
  history:   { operador: false, tecnico: false, supervisor: true,  engineer: true,  gerente: true,  admin: false, super_usuario: false },
  // avisos: reporte de fallas desde planta. Quienes reportan ven los suyos; supervisor y gerente ven el repositorio
  // completo, pero solo el supervisor decide (gestionar_avisos).
  avisos:    { operador: true, tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: false, super_usuario: false },
};

// =============================================================================
// MATRIZ DE ACCIONES (idéntica a ACCIONES en permissions.py)
// =============================================================================

export const ACCIONES: Record<AccionKey, Record<string, boolean>> = {
  // El administrador gobierna el sistema, no opera el mantenimiento: no crea, cambia, cancela ni elimina OT.
  // Crear una OT directamente (sin un aviso de falla previo) es SOLO del supervisor, igual que generarla desde un aviso.
  // Gerente e ingeniero consultan las OT, no las operan.
  crear_ot:           { operador: false, tecnico: false, supervisor: true,  engineer: false, gerente: false, admin: false, super_usuario: false },
  cambiar_estado_ot:  { operador: false, tecnico: false, supervisor: true,  engineer: false,  gerente: false, admin: false, super_usuario: false },
  cancelar_ot:        { operador: false, tecnico: false, supervisor: true,  engineer: false, gerente: false, admin: false, super_usuario: false },
  // Eliminar borra el historial de la OT: ningún perfil puede (el backend responde 403). Lo normal es cancelar.
  eliminar_ot:        { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: false, admin: false, super_usuario: false },
  subir_documentos:   { operador: false, tecnico: false, supervisor: false, engineer: true,  gerente: false, admin: true, super_usuario: false },
  gestionar_usuarios: { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: true, admin: true, super_usuario: true },
  eliminar_documentos: { operador: false, tecnico: false, supervisor: false, engineer: true,  gerente: false, admin: true, super_usuario: false },
  gestionar_empresas: { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: false, admin: false, super_usuario: true },
  ver_usuarios:       { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: true, admin: true, super_usuario: true },
  // Aviso de falla -> OT: reportar desde planta, y decidir (generar OT o descartar) en el repositorio del supervisor.
  reportar_falla:      { operador: true,  tecnico: true,  supervisor: true,  engineer: true,  gerente: true,  admin: false, super_usuario: false },
  gestionar_avisos:    { operador: false, tecnico: false, supervisor: true,  engineer: false, gerente: false,  admin: false, super_usuario: false },
  asignar_ot:          { operador: false, tecnico: false, supervisor: true,  engineer: false, gerente: false,  admin: false, super_usuario: false },
  // Costo directo, ahorro, impacto anual y ranking por costo del dashboard: solo el gerente (el backend omite los campos).
  ver_kpis_financieros: { operador: false, tecnico: false, supervisor: false, engineer: false, gerente: true,  admin: false, super_usuario: false },
  // Solo sobre la OT que tiene asignada (el backend lo valida).
  iniciar_ot_asignada: { operador: false, tecnico: true,  supervisor: false, engineer: false, gerente: false, admin: false, super_usuario: false },
};

/** Roles que ven el repositorio completo de avisos de su empresa (espejo de ROLES_REPOSITORIO_AVISOS). Solo el supervisor decide. */
export const ROLES_REPOSITORIO_AVISOS: readonly Role[] = ['supervisor', 'gerente'];

// =============================================================================
// VALIDACIONES DE ACCESO
// =============================================================================

/**
 * Verifica si un rol puede acceder a una ruta.
 * Si soloLectura es true, acepta también el permiso 'ver'.
 */
export const puedeAccederRuta = (
  role: Role | null | undefined,
  ruta: RutaKey,
  soloLectura = true
): boolean => {
  if (!role) return false;
  const permiso = RUTAS[ruta]?.[role];
  if (permiso === true) return true;
  if (soloLectura && permiso === 'ver') return true;
  return false;
};

/**
 * Verifica si un rol puede ejecutar una acción.
 */
export const puedeEjecutarAccion = (
  role: Role | null | undefined,
  accion: AccionKey
): boolean => {
  if (!role) return false;
  return ACCIONES[accion]?.[role] === true;
};

/**
 * Retorna la primera ruta accesible para el rol dado, usada tras el login.
 */
export const getDefaultRouteForRole = (role: Role | null | undefined): string => {
  // El super_usuario (contraparte comercial de BARB) solo administra empresas: aterriza en su mantenedor.
  if (puedeAccederRuta(role, 'empresas')) return '/empresas';
  // En planta el día empieza por los avisos: quien reporta ve los suyos y el supervisor, los pendientes de decidir.
  if ((role === 'operador' || role === 'supervisor') && puedeAccederRuta(role, 'avisos')) return '/avisos';
  if (puedeAccederRuta(role, 'dashboard')) return '/dashboard';
  if (puedeAccederRuta(role, 'menu')) return '/work-orders';
  return '/login';
};

// =============================================================================
// HELPERS PARA RUTAS CON FORMATO '/nombre'
// =============================================================================

export type AppPage = `/${RutaKey}`;

export const canAccessPage = (
  role: Role | null | undefined,
  page: AppPage,
  soloLectura = true
): boolean => puedeAccederRuta(role, page.slice(1) as RutaKey, soloLectura);

export const canPerformAction = (
  role: Role | null | undefined,
  action: AccionKey
): boolean => puedeEjecutarAccion(role, action);
