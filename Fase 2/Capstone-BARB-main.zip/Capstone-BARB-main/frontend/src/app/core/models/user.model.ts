// =============================================================================
// USUARIOS Y ROLES
// =============================================================================
//
// Roles reales del backend (permissions.py ROLES): operador, tecnico,
// supervisor, engineer, gerente, admin, super_usuario. El backend devuelve el
// rol en minúsculas (ver auth.py login: str(user["rol"]).lower()).
//

export type Role =
  | 'operador'
  | 'tecnico'
  | 'supervisor'
  | 'engineer'
  | 'gerente'
  | 'admin'
  // Operador de la plataforma BARB: no pertenece a una empresa y ve todas.
  | 'super_usuario'
  | (string & {});

export interface User {
  id: string | number;
  name: string;
  role: Role;
  token?: string;
  activo?: boolean;
  // Multi-empresa: null para el super_usuario (no pertenece a ninguna empresa).
  empresa_id?: number | null;
  empresa_nombre?: string | null;
}

// =============================================================================
// AUTENTICACIÓN (contrato exacto de /api/auth/login)
// =============================================================================

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  token: string;
  user: {
    id: number;
    name: string;
    role: Role;
    empresa_id: number | null;
    empresa_nombre: string | null;
  };
}

// =============================================================================
// GESTIÓN DE USUARIOS (admin) — contrato de /api/usuarios
// =============================================================================

export interface UserCreateRequest {
  nombre: string;
  email: string;
  password: string;
  rol: string;
  activo?: boolean;
  // Solo lo respeta el backend para el super_usuario; el admin siempre crea en su empresa.
  empresa_id?: number | null;
}

/** Perfil de usuario tal como lo devuelve GET /api/usuarios. */
export interface UsuarioPerfil {
  usuario_id: number;
  nombre: string;
  email: string;
  rol: Role;
  activo: boolean;
  created_at: string | null;
  ultimo_login: string | null;
  empresa_id: number | null;
  empresa_nombre: string | null;
}

/** Respuesta de POST /api/usuarios: el perfil creado y quién lo creó (contacto del aviso de bienvenida). */
export interface UsuarioCreado extends UsuarioPerfil {
  creado_por: { nombre: string; email: string };
}

export interface UserUpdateRequest {
  nombre?: string;
  email?: string;
  password?: string;
  rol?: string;
  activo?: boolean;
}
