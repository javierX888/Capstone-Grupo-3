// frontend/src/app/core/services/chat.service.ts

import { Injectable, inject } from '@angular/core';
import { TenantContextService } from './tenant-context.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import {
  ChatRequest,
  ChatStreamEvent,
  DeleteSessionResponse,
  MultimediaRequest,
  SessionDetailResponse,
  SessionListResponse,
} from '../models/chat.model';
import { AuthService } from './auth.service';
import { ToastService } from './toast.service';
import { I18nService } from '../i18n/i18n.service';
import { environment } from '../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class ChatService {
  private readonly http = inject(HttpClient);
  private readonly tenant = inject(TenantContextService);
  private readonly auth = inject(AuthService);
  private readonly toast = inject(ToastService);
  private readonly i18n = inject(I18nService);
  private readonly baseUrl = `${environment.apiUrl}/chat`;

  // ---------------------------------------------------------------------------
  // Chat en streaming (HU-03) y multimodal (HU-05, CGBIDA-276)
  // ---------------------------------------------------------------------------

  streamChat(payload: ChatRequest): Observable<ChatStreamEvent> {
    // Mismos mensajes que históricamente mostraba el stream textual.
    return this.postSse('/stream', payload, {
      429: 'Demasiadas peticiones. Espera un momento.',
      422: 'Mensaje inválido (vacío o demasiado largo).',
    });
  }

  /**
   * Turno multimodal: imagen (data URL) + pregunta, atendido por el modelo
   * multimodal del backend (mismos eventos SSE que el stream textual).
   * Contrato: docs/contrato_api_chat_multimedia.md.
   */
  streamMultimedia(payload: MultimediaRequest): Observable<ChatStreamEvent> {
    const t = this.i18n.t('docChat');
    return this.postSse('/multimedia', payload, {
      400: t.errImageOrQuestionRequired,
      413: t.errImageTooLarge,
      422: t.errImageInvalidFormat,
      429: t.errRateLimit,
      503: t.errMultimodalUnavailable,
    });
  }

  /**
   * POST + lectura del stream SSE compartido por el chat textual y el
   * multimodal. El stream usa fetch nativo (no pasa por authInterceptor):
   * el 401 se maneja aquí → logout + redirect a /login.
   *
   * @param statusErrors Mensajes por código HTTP (además del 401 genérico).
   */
  private postSse(
    path: string,
    payload: object,
    statusErrors: Record<number, string>,
  ): Observable<ChatStreamEvent> {
    return new Observable<ChatStreamEvent>((subscriber) => {
      if (this.tenant.isSuper() && this.tenant.empresaId() === null) {
        subscriber.error(new Error('Selecciona una empresa en la cabecera para consultar su documentación.'));
        return;
      }
      const controller = new AbortController();
      const token = localStorage.getItem('barb_token');

      const headers: Record<string, string> = {
        'Content-Type': 'application/json',
      };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      fetch(`${this.baseUrl}${path}`, {
        method: 'POST',
        headers,
        // super_usuario: indica qué empresa consulta (el backend lo ignora para usuarios de empresa).
        body: JSON.stringify(
          this.tenant.isSuper() ? { ...payload, empresa_id: this.tenant.empresaId() } : payload,
        ),
        signal: controller.signal,
      })
        .then(async (response) => {
          if (response.status === 401) {
            this.toast.show(this.i18n.t('common').sessionExpired, 'error');
            this.auth.logout();
            subscriber.error(new Error('Sesión expirada. Vuelve a iniciar sesión.'));
            return;
          }
          const statusMessage = statusErrors[response.status];
          if (statusMessage) {
            subscriber.error(new Error(statusMessage));
            return;
          }
          if (!response.ok) {
            subscriber.error(new Error(`HTTP ${response.status}`));
            return;
          }

          const reader = response.body?.getReader();
          if (!reader) {
            subscriber.error(new Error('No response body'));
            return;
          }

          const decoder = new TextDecoder();
          let buffer = '';

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder
              .decode(value, { stream: true })
              .replace(/\r\n/g, '\n');

            let separatorIdx: number;
            while ((separatorIdx = buffer.indexOf('\n\n')) !== -1) {
              const block = buffer.slice(0, separatorIdx);
              buffer = buffer.slice(separatorIdx + 2);

              const parsed = this.parseSseEvent(block);
              if (parsed) subscriber.next(parsed);
            }
          }

          subscriber.complete();
        })
        .catch((err) => {
          if (err.name !== 'AbortError') subscriber.error(err);
        });

      return () => controller.abort();
    });
  }

  private parseSseEvent(raw: string): ChatStreamEvent | null {
    const lines = raw.split('\n');
    let eventType = 'message';
    let dataLine = '';

    for (const line of lines) {
      if (line.startsWith('event:')) {
        eventType = line.slice(6).trim();
      } else if (line.startsWith('data:')) {
        dataLine = line.slice(5).trim();
      }
    }

    if (!dataLine) return null;

    try {
      return { type: eventType, data: JSON.parse(dataLine) } as ChatStreamEvent;
    } catch (e) {
      console.warn('[ChatService] No se pudo parsear el evento SSE:', raw, e);
      return null;
    }
  }

  // ---------------------------------------------------------------------------
  // Historial de conversaciones (CGBIDA-254/255/256)
  // ---------------------------------------------------------------------------

  listSessions(limit = 20, offset = 0): Observable<SessionListResponse> {
    const params = new HttpParams()
      .set('limit', String(limit))
      .set('offset', String(offset));
    return this.http.get<SessionListResponse>(`${this.baseUrl}/sessions`, { params });
  }

  getSession(sessionId: string): Observable<SessionDetailResponse> {
    return this.http.get<SessionDetailResponse>(
      `${this.baseUrl}/sessions/${sessionId}`,
    );
  }

  deleteSession(sessionId: string): Observable<DeleteSessionResponse> {
    return this.http.delete<DeleteSessionResponse>(
      `${this.baseUrl}/sessions/${sessionId}`,
    );
  }
}
